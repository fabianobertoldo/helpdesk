<?php
    
    
    function selectIdPorDataHoraUser($data_abertura, $hora_abertura, $nome ){
        include "config.php";
        include "layout.php";
        $sQuery = " select codigo
        from   chamados 
        where  data_abertura = '" . $data_abertura . "' and hora_abertura = '" . $hora_abertura . "' and nome = '" . $nome . "'";

        $id = $mysqli->query($sQuery);
        $codigo;
        while ($oRow = $id->fetch_object()){  
            $codigo = $oRow->codigo;
        }
        return $codigo;
    }
    
    
    
?>