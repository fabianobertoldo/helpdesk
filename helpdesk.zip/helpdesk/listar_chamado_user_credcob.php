<?php

    include "config.php";
     $ip = getenv("REMOTE_ADDR");
     include "layout.php";
     include "convertedata.php";  
    $sQuery = " select codigo, data_abertura, data_fecha, hora_abertura, hora_fecha, setor, ip, descricao, solucao, tipo, nome, status, obs
                from   chamados
                 where  setor ='credcob'
                order by codigo desc";

    $oUsers = $mysqli->query($sQuery);
    $num_registros = $oUsers->num_rows;
    $setor = "Loja1";
?>



<script>
    function excluir(id){
        if (confirm('Confirmar Exclus�o?')){
            alert("Voc� n�o pode excluir chamados!");
    	}
    }
    function alterar(id){
        window.location = 'novo_chamado.php?id='+id;
    }
    function visualizar(id){
        window.location = 'visu_chamado.php?id='+id;
    }
</script>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<script  src="https://code.jquery.com/jquery-3.2.1.min.js"></script>


<link rel="stylesheet" type="text/css" href="./css/style.css"> 
<link rel="stylesheet" type="text/css" href="./css/normalize.css"> 
<link rel="stylesheet" type="text/css" href="./css/print.css" media="print" > 
 <TITLE><?php echo $Title ?></TITLE>
 <meta equiv="refresh" content="5">


<script type="text/javascript">
  // Solicita a permiss�o para realizar as notifica��es
  document.addEventListener('DOMContentLoaded', function () {
    if (Notification.permission !== "granted")
      Notification.requestPermission();
    });
  // Fun��o para exibir as notifica��es
  function NofiticacaoGoogleChrome() {
  if (!Notification) {
    alert('Notifica��es de �rea de trabalho que n�o est�o dispon�veis no seu navegador. Tente com o navegador Google Chrome');
  return;
  }
   
  if (Notification.permission !== "granted")
    Notification.requestPermission();
  else {
  var notification = new Notification('Titulo da Notifica��o - Nome do Site', {
  icon: '<a href="http://charlescorrea.com.br/blog/tag/https">https</a>://cdn3.iconfinder.com/data/icons/ose/Warning.png',
  body: 'Lorem Ipsum � simplesmente uma simula��o de <a href="http://charlescorrea.com.br/blog/tag/texto">texto</a> da ind�stria tipogr�fica e de impressos, e vem sendo utilizado desde o s�culo XVI, quando um impressor desconhecido pegou uma bandeja de tipos.',
  });
   
  notification.onclick = function () {
  window.open("http://site.com.br/pagina.html");
  };
   
  }
   
  }
</script>

 <script type="text/javascript">





jQuery(document).ready(function() {




    window.setTimeout('location.reload()', 30000);
  
    var maskHeight = $(document).height();
    var maskWidth = $(window).width();
  
    $('#mask').css({'width':maskWidth,'height':maskHeight});
 
    $('#mask').fadeIn(1000);  
    $('#mask').fadeTo("slow",0.8);
  
    //Get the window height and width
    var winH = $(window).height();
    var winW = $(window).width();
              
    $('#dialog2').css('top',  winH/2-$('#dialog2').height()/2);
    $('#dialog2').css('left', winW/2-$('#dialog2').width()/2);
  
    $('#dialog2').fadeIn(500);
    $('#dialog2').fadeOut(20000);  
  
  $('.window .close').click(function (e) {
    e.preventDefault();
    
    $('#mask').hide();
    $('.window').hide();
  });   
  
  $('#mask').click(function () {
    $(this).hide();
    $('.window').hide();
  });     
  
});
</script>
 
<style type="text/css">
 
#mask {
  position:absolute;
  left:0;
  top:0;
  z-index:9000;
  background-color:transparent;
  display:none;
}
  
#boxes .window {
  position:absolute;
  left:0;
  top:0;
  width:150px;
  height:150px;
  display:none;
  z-index:9999;
  padding:20px;
}
 
#boxes #dialog2 {
  background: #eaf3f3;
    width: 350px;
    margin: 0 auto;
    margin-top: -100px;
    border: #167f92 4px solid;
    border-radius: 9px;
}
 
.close{display:block; text-align:right;width: 10px; height: 10px;}
 
</style>

</head>






<body  bgcolor="#FFDAB9" style="margin-top: -16px;">


  <div id="boxes">
 
<!-- Janela Modal -->
    <div id="dialog2" class="window">
      <div align="right">
        <span   class="close"><img style="width: 23px; margin: -14px 0px 0px 2px" src="img/fechar.png"><span/>
      </div>
      <div>
        <span>Seja bem-vindo ao novo helpdesk H2B!</span></br>
        </br>
        <span>Nesta p&aacutegina voc&ecirc poder&aacute acompanhar o andamento da sua solicita&ccedil&acirco junto ao setor de T.I.</span></br></br>
        <span>Poder&aacute Tamb&eacutem abrir novos chamados.</span>
      </div>
    <div>
        
      </div>
    </div>
<!-- Fim Janela Modal-->
 
<!-- M�scara para cobrir a tela -->
<div id="mask"></div>
 
</div>



    
    <table class="responstable">
  
  <tr>
    
    <th width="30"><font style="COLOR: #f2f2f2;" size="1" face="verdana" color="#000000">

    <center>C�DIGO</center></font></th>
    <th width="70"><font style="
    COLOR: #f2f2f2;
" size="1" face="verdana" color="#000000"><center>DT. ABERT.</center></font></th>
    <th width="70"><font style="
    COLOR: #f2f2f2;
" size="1" face="verdana" color=" #000000"><center>HR ABERTURA.</center></font></th>
    <th width="150"><font style="
    COLOR: #f2f2f2;
" size="1" face="verdana" color=" #000000"><center>SETOR</center></font></td>
    <th width="50%"><font style="
    COLOR: #f2f2f2;
" size="1" face="verdana" color=" #000000"><center>DESC. PROBLEMA</center></font></th>
<th width="70%"><font style="
    COLOR: #f2f2f2;
" size="1" face="verdana" color=" #000000"><center>SOLU��O DO PROBLEMA</center></font></th>
    <th width="50"><font style="
    COLOR: #f2f2f2;
" size="1" face="verdana" color=" #000000"><center>TIPO</center></font></th>
    <th width="160"><font style="
    COLOR: #f2f2f2;
" size="1" face="verdana" color=" #000000"><center>NOME</center></font></th>
    <th width="100"><font style="
    COLOR: #f2f2f2;
" size="1" face="verdana" color=" #000000"><center>STATUS</center></font></th>
  </tr>
  
  <?php   
        while ($oRow = $oUsers->fetch_object()){       

           $oRow->data_abertura = converteData($oRow->data_abertura);

            echo "<tr >
                  
                  <td><center><a href=\"#\" style=\"text-decoration: none\"><font color=\"$cor_dados\">$oRow->codigo</font></center></td>
                  <td><center><a href=\"#\" style=\"text-decoration: none\"><font color=\"$cor_dados\">
                  $oRow->data_abertura   </font></center></td>
                  <td><center><a href=\"#\" style=\"text-decoration: none\"><font color=\"$cor_dados\">$oRow->hora_abertura</font></center></td>
                  <td><center><a href=\"#\" style=\"text-decoration: none\"><font color=\"$cor_dados\">$oRow->setor</font></center></td>
                  <td><center><a href=\"#\" style=\"text-decoration: none\"><font color=\"$cor_dados\">$oRow->descricao</font></center></td>
                  <td><center><a href=\"#\" style=\"text-decoration: none\"><font color=\"$cor_dados\">$oRow->solucao</font></center></td>
                  <td><center><a href=\"#\" style=\"text-decoration: none\"><font color=\"$cor_dados\">$oRow->tipo</font></center></td>
                  <td><center><a href=\"#\" style=\"text-decoration: none\"><font color=\"$cor_dados\">$oRow->nome</font></a></center></td>
                  <td><center><a href=\"#\" style=\"text-decoration: none\"><font color=\"$cor_dados\">$oRow->status</font></center></td>
                  </tr>";     
        }
      ?>
  
  
  
</table>
    
    

</body>
</html>
