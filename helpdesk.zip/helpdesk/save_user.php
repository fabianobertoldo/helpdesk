<?php
    include "config.php";
    include "valida_user.inc";
    include "layout.php";
    mysql_connect($Host, $Usuario, $Senha);
    mysql_select_db($Base);


    mysql_select_db($Base);

    $user = $_POST["login"];
//    $pwd  = $HTTP_POST_VARS["senha"];

    $sQuery = "select cod_usuario, nom_usuario, login, pwd_usuario, nivel
               from   usuarios
               where  login = '" . $user . "'";
    $oUser = mysql_query($sQuery)
             or die("Query invalida: " . mysql_error());

    $row = mysql_fetch_object($oUser);
    if ($num_rows = mysql_num_rows($oUser) == 1) {
        ?>
            <script language="JavaScript">
            <!--
            alert("Usuário já cadastrado!");
            window.location = 'listar_user.php';
            //-->
            </script>
        <?php
        }
     else {
        $sQuery = "insert into usuarios (nom_usuario, login, pwd_usuario, nivel)
                 values ('" . $_POST["nom_usuario"] . "',
                         '" . $_POST["login"] . "',
                         '" . $_POST["pwd_usuario"] . "',
                         '" . $_POST["nivel"]  . "')";
                         
        mysql_query($sQuery);
        echo "<script>window.location='listar_user.php'</script>";
           }
?>

