<?php
    $date = date("d/m/y");
    $hora = date("H:i");

    include "config.php";
    include "valida_user.inc";
     include "layout.php";

$tipo_relatorio = ($HTTP_POST_VARS["setor"]);

    mysql_connect($Host, $Usuario, $Senha);
    mysql_select_db($Base);
    
    $sQuery = " select codigo, setor, ip, descricao, solucao, tipo, nome, status, obs
                from   chamados
                where status like '$tipo_relatorio%'
                order by codigo";
    $oUsers = mysql_query($sQuery);
    $num_registros = mysql_num_rows($oUsers);
?>

<html>
<head>
 <TITLE>Relat�rio de Chamados por Setor definido como: <?php echo $tipo_relatorio ?></TITLE>

</head>
<body>

<table border="0" width="600">
  <tr>
    <td><b><font face="Arial" size="2">Relat�rio de Chamados por Status definido como:</font><font face="Arial" size="2" color="Blue"> <u><?php echo $tipo_relatorio ?></u> </font></b></td>
  </tr>
</table>

<p>
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="995">
  <tr>
    <td width="44" align="center">
    <p align="left"><b><font face="Arial" size="2">Cod</font></b></td>
    <td width="143" align="center">
    <p align="center"><b><font face="Arial" size="2">Setor</font></b></td>
    <td width="29" align="center"><b><font face="Arial" size="2">IP</font></b></td>
    <td width="300" align="center">
    <p align="center"><b><font face="Arial" size="2">Descri��o</font></b></td>
    <td width="300" align="center">
    <p align="center"><b><font face="Arial" size="2">Solu��o</font></b></td>
    <td width="35" align="center">
    <p align="center"><b><font face="Arial" size="2">Tipo</font></b></td>
    <td width="144" align="center">
    <p align="center"><b><font face="Arial" size="2">Nome</font></b></td>
  </tr>
          <?php
        while ($oRow = mysql_fetch_object($oUsers)) {
            echo "<tr>
                      <td><font face=\"arial\" size=\"2\"><center>$oRow->codigo</font></center></td>
                      <td><font face=\"arial\" size=\"2\"><center>$oRow->setor</font></center></td>
                      <td><font face=\"arial\" size=\"2\"><center>$oRow->ip</font></center></td>
                      <td><font face=\"arial\" size=\"2\">$oRow->descricao</font></td>
                      <td><font face=\"arial\" size=\"2\">$oRow->solucao</font></td>
                      <td><font face=\"arial\" size=\"2\"><center>$oRow->tipo</font></center></td>
                      <td><font face=\"arial\" size=\"2\"><center>$oRow->nome</font></center></td>
                  </tr>";
        }
        ?>
</table>

<table border="0" width="600">
  <tr>
    <td width="450"><b><font face="Arial" size="1">Relat�rio emitido em <?php echo $date ?> as <?php echo $hora ?>, pelo usu�rio <?php echo $nome_usuario ?></font></B></td>
    <td width="20"><a href="javascript:window.close()"><img src="img/voltar.gif" border="0" alt="Clique para Fechar"></a></td>
    <td width="360"><a href="javascript:parent.print()"><img src="img/imprimi.jpg" border="0" alt="Clique para imprimir o Relat�rio"></a></td>
  </tr>
  <tr>
    <td colspan="3"><b><font face="Arial" size="1">N�mero de Chamados <?php echo $tipo_relatorio ?>: <?php echo $num_registros ?></font></B>
    </td>
  </tr>
</table>

</body>
</html>
