<?php
    ini_set('default_charset','UTF-8');
    include "config.php";
    include "layout.php";    
    $ip = getenv("REMOTE_ADDR");
   
?>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="./css/style.css"> 
    <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
    
</head>
<body>

    <div style="margin-top: -46px;" class="container">    
           <div id="loginbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
            <div class="panel panel-info" >
                    <div class="panel-heading">
                        <div class="panel-title">ABRIR CHAMADO</div>
                    </div>     
                    <div style="padding-top:30px" class="panel-body" >
                        <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
    
                        <form name="form1" method="post" action="save_chamado_user.php" id="loginform" class="form-horizontal" role="form">
                                    
                            <div style="margin-bottom: 25px" class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                <input required="yes" id="login-username" type="text" class="form-control" name="nome" value="" placeholder="Informe seu nome">                                        
                            </div>
                                
                            <div style="margin-bottom: 25px" class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
                                <input required="yes" id="login-password" type="email" class="form-control" name="email" placeholder="email da loja/setor/pessoal">
                            </div>
                            <div style="margin-bottom: 25px" class="input-group">
                                 <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                <select required="yes" class="form-control" size="1" name="setor" >
                                    <option value="">Setor/Loja</option>
                                    <option value="CONFERÊNCIA">Conferência</option>
                                    <option value="ESTOQUE">Estoque</option>
                                    <option value="DP">DP</option>
                                    <option value="FINANCEIRO">Financeiro</option>
                                    <option value="RH">RH</option>
                                    <option value="Laboratório">Laboratório</option>
                                    <option value="TLMK">TLMK</option>
                                    <option value="CRÉDITO">CRÉDITO</option>
                                    <option value="CASA DE MARIA">Casa de Maria</option>
                                    <?php for ($i=1; $i < 47; $i++) { 
                                        echo "<option value='Loja".$i."'>Loja".$i."</option>";
                                    }?>
                                         
                                  
                             
                                </select>      
                                
                           
                            </div>

                            <div style="margin-bottom: 25px" class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-tag"></i></span>
                                <select required="yes" class="form-control" size="1" name="tipo" >
                                    <option value="Hardware">Escolha o motivo do chamado</option>
                                    <option value="Saldo de lentes/aliancas"> Saldo de lentes/alianças</option>
                                    <option value="Computador">Computador</option>
                                    <option value="Sistema">Sistema</option>
                                    <option value="Impressora">Impressora/toner</option>
                                    <option value="Telefonia">Telefonia</option>
                                    <option value="Cameras">Cameras</option>
                                    <option value="Dúvidas">Dúvidas</option>
                                    <option value="Outros">Outros</option>
                                </select>
                            </div>
                            <div style="margin-bottom: 25px" class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-text-width"></i></span>
                                <textarea required="yes" class="form-control" rows="3" cols="42" name="descricao" placeholder="Descreva sua solicitação." ></textarea>
                            </div>
                            
                            <div style="margin-top:10px" class="form-group">
                                    <!-- Button -->
                                <div class="col-sm-12 controls">
                                <input class="btn btn-success" type = "submit" name="Submit" value ="Enviar">
                            </div>
                            <input type="hidden" name="ip" value="<?php echo $ip?>" />
                        </form>     
                    </div>                     
                </div>  
            </div>
        </div> 
    </div>
</body>
</html>