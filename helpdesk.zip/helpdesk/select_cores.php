<?php
include "config.php";
include "layout.php";

 $mysqli = new mysqli($Host,  $Usuario, $Senha, $Base);
    
$sQuery_select = " select cor
            from   cores
            order by cor";
$oUsers_select = $mysqli->query($sQuery_select);
$num_registros = $oUsers_select->num_rows;


while ($oRow_select = $oUsers_select->fetch_object()){
       echo "<option style=\"background-color: $oRow_select->cor\" value=\"$oRow_select->cor\">$oRow_select->cor</option>";
}



?>
