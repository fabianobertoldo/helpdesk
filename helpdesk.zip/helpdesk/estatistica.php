<?php

    include "config.php";
    include "valida_user.inc";
     include "layout.php";

   $mysqli = new mysqli($Host,  $Usuario, $Senha, $Base);

    $sQuery = " select codigo, data_abertura, data_fecha, hora_abertura, hora_fecha, setor, ip, descricao, solucao, tipo, nome, status, obs
                from   chamados
                where status like 'a%'
                order by status";
    $oUsers = $mysqli->query($sQuery);
    $num_registros = $oUsers->num_rows;

    $sQuery = " select codigo, data_abertura, data_fecha, hora_abertura, hora_fecha, setor, ip, descricao, solucao, tipo, nome, status, obs
                from   chamados
                where status like 'e%'
                order by status";
    $oUsers = $mysqli->query($sQuery);
    $num_registros1 = $oUsers->num_rows;

    $sQuery = " select codigo, data_abertura, data_fecha, hora_abertura, hora_fecha, setor, ip, descricao, solucao, tipo, nome, status, obs
                from   chamados
                where status like 'f%'
                order by status";
    $oUsers = $mysqli->query($sQuery);
    $num_registros2 = $oUsers->num_rows;
    
    $sQuery = " select codigo, data_abertura, data_fecha, hora_abertura, hora_fecha, setor, ip, descricao, solucao, tipo, nome, status, obs
                from   chamados
                where status like ''
                order by status";
     $oUsers = $mysqli->query($sQuery);
    $num_registros3 = $oUsers->num_rows;
    

    $sQuery = " select codigo, data_abertura, data_fecha, hora_abertura, hora_fecha, setor, ip, descricao, solucao, tipo, nome, status, obs
                from   chamados
                order by status";
     $oUsers = $mysqli->query($sQuery);
    $num_registros4 = $oUsers->num_rows;
    
    $sQuery = " select codigo, data_abertura, data_fecha, hora_abertura, hora_fecha, setor, ip, descricao, solucao, tipo, nome, status, obs
                from   chamados
                where status like 'a%' and tipo like 'hard%'
                order by status";
     $oUsers = $mysqli->query($sQuery);
    $num_registros5 = $oUsers->num_rows;

    $sQuery = " select codigo, data_abertura, data_fecha, hora_abertura, hora_fecha, setor, ip, descricao, solucao, tipo, nome, status, obs
                from   chamados
                where status like 'a%' and tipo like 'soft%'
                order by status";
     $oUsers = $mysqli->query($sQuery);
    $num_registros6 = $oUsers->num_rows;
    
    $sQuery = " select codigo, data_abertura, data_fecha, hora_abertura, hora_fecha, setor, ip, descricao, solucao, tipo, nome, status, obs
                from   chamados
                where status like 'a%' and tipo like 'duvi%'
                order by status";
     $oUsers = $mysqli->query($sQuery);
    $num_registros7 = $oUsers->num_rows;
    
    $sQuery = " select codigo, data_abertura, data_fecha, hora_abertura, hora_fecha, setor, ip, descricao, solucao, tipo, nome, status, obs
                from   chamados
                where status like 'a%' and tipo like 'outr%'
                order by status";
     $oUsers = $mysqli->query($sQuery);
    $num_registros8 = $oUsers->num_rows;




?>

<html>
<head>
 <TITLE><?php echo $Title ?></TITLE>
 <link rel="stylesheet" type="text/css" href="./css/style.css"> 
<link rel="stylesheet" type="text/css" href="./css/normalize.css"> 
<link rel="stylesheet" type="text/css" href="./css/print.css" media="print"> 
</head>
<body style="font-family: verdana; font-size:11;" bgcolor="#FFDAB9"<?php echo $cor_pagina ?>">
<table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="500">
  <tr>
    <td><center><img src="img/barra_esta.jpg"></center></td>
  </tr>
</table>

<p>

<div align="center">
  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600">
    <tr>
      <td colspan="2"><font face="verdana" size="2"><b><center>Total de Chamados pos Status</center></b></font></td>
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td width="300"><font face="verdana" size="1"><b>Total de Chamados Abertos</b></font></td>
      <td width="300"><font face="verdana" size="1"><b><?php echo "  (" . $num_registros . ")" ?></b></font></td>
    </tr>
    <tr>
      <td width="300"><font face="verdana" size="1"><b>Total de Chamados Em Andamento</b></font></td>
      <td width="300"><font face="verdana" size="1"><b><?php echo "  (" . $num_registros1 . ")" ?></b></font></td>
    </tr >
    <tr>
      <td width="300"><font face="verdana" size="1"><b>Total de Chamados Fechados</b></font></td>
      <td width="300"><font face="verdana" size="1"><b><?php echo "  (" . $num_registros2 . ")" ?></b></font></td>
    </tr>
    <tr>
      <td width="300"><font face="verdana" size="1"><b>Total de Chamados Sem Status</b></font></td>
      <td><font face="verdana" size="1"><b><?php echo "  (" . $num_registros3 . ")" ?></b></font></td>
    </tr>
    <tr>
      <td colspan="2"><hr width="350" align="left" color="black"></td>
    </tr>
    <tr>
      <td width="300"><font face="verdana" size="1"><b>Total de Chamados</b></font></td>
      <td><font face="verdana" size="1"><b><?php echo "  (" . $num_registros4 . ")" ?></b></font></td>
    </tr>
  </table>
</div>
&nbsp;<p>
<hr width="600"><p>


<div align="center">
  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600">
    <tr>
      <td colspan="2"><font face="verdana" size="2"><b><center>Total de Chamados Abertos por Tipo </center></b></font></td>
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td width="300"><font face="verdana" size="1"><b>Total de Chamados Hardware</b></font></td>
      <td width="300"><font face="verdana" size="1"><b><?php echo "  (" . $num_registros5 . ")" ?></b></font></td>
    </tr>
    <tr>
      <td width="300"><font face="verdana" size="1"><b>Total de Chamados Software</b></font></td>
      <td width="300"><font face="verdana" size="1"><b><?php echo "  (" . $num_registros6 . ")" ?></b></font></td>
    </tr >
    <tr>
      <td width="300"><font face="verdana" size="1"><b>Total de Chamados Duvidas</b></font></td>
      <td width="300"><font face="verdana" size="1"><b><?php echo "  (" . $num_registros7 . ")" ?></b></font></td>
    </tr>
    <tr>
      <td width="300"><font face="verdana" size="1"><b>Total de Chamados Outros</b></font></td>
      <td><font face="verdana" size="1"><b><?php echo "  (" . $num_registros8 . ")" ?></b></font></td>
    </tr>
  </table>
</div>



</body>
</html>
