<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
	<body>
		<table style="margin: 1em 0; width: 50%; overflow: hidden; background: #FFF; color: #024457;  border-radius: 10px; border: 1px solid #167F92;">	  
			<tbody>
			  	<tr style="background-color: #167F92;">    
			    	<th width="30"><font style="COLOR: #f2f2f2;" size="1" face="verdana" color="#000000">
				    	<center>CóDIGO</center></font>
			    	</th>

				    <th width="70"><font style="
						    COLOR: #f2f2f2;
						" size="1" face="verdana" color="#000000"><center>DT. ABERT.</center></font>
					</th>
				    <th width="70"><font style="
						    COLOR: #f2f2f2;
						" size="1" face="verdana" color=" #000000"><center>HR ABERTURA.</center></font>
					</th>
				    <th width="150"><font style="
						    COLOR: #f2f2f2;
						" size="1" face="verdana" color=" #000000"><center>SETOR</center></font>
				    </th>
				    <th width="50%"><font style="
						    COLOR: #f2f2f2;
						" size="1" face="verdana" color=" #000000"><center>DESC. PROBLEMA</center></font>
					</th>
					<th width="70%"><font style="
						    COLOR: #f2f2f2;
						" size="1" face="verdana" color=" #000000"><center>SOLUÇÃO DO PROBLEMA</center></font>
					</th>
				    <th width="50"><font style="
						    COLOR: #f2f2f2;
						" size="1" face="verdana" color=" #000000"><center>TIPO</center></font>
					</th>
				    <th width="160"><font style="
						    COLOR: #f2f2f2;
						" size="1" face="verdana" color=" #000000"><center>NOME</center></font>
					</th>
				    <th width="100"><font style="
						    COLOR: #f2f2f2;
						" size="1" face="verdana" color=" #000000"><center>STATUS</center></font>
					</th>
			    </tr>	
			  
			    <tr style="background-color: aliceblue;">                  
			      	<td><center><a href="#" style="text-decoration: none"><font color="#000000">9451</font></a></center></td>
			      	<td><center><a href="#" style="text-decoration: none"><font color="#000000">01/03/2019</font></a></center></td>
			     	<td><center><a href="#" style="text-decoration: none"><font color="#000000">08:29</font></a></center></td>
			      	<td><center><a href="#" style="text-decoration: none"><font color="#000000">Loja37</font></a></center></td>
			      	<td><center><a href="#" style="text-decoration: none"><font color="#000000">teste</font></a></center></td>
			      	<td><center><a href="#" style="text-decoration: none"><font color="#000000"></font></a></center></td>
			      	<td><center><a href="#" style="text-decoration: none"><font color="#000000">Hardware</font></a></center></td>
			      	<td><center><a href="#" style="text-decoration: none"><font color="#000000">Hailton Hito</font></a></center></td>
			      	<td><center><a href="#" style="text-decoration: none"><font color="#000000">Aberto</font></a></center></td>
			    </tr>  
			</tbody>
		</table>
		<h1>ACOMPANHE O ANDAMENTO DO SEU CHAMADO NA PAGINA DO HELPDESK</h1>
	</body>
</html>

