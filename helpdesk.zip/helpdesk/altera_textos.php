<?php
    include "config.php";
    include "valida_user.inc";
?>

<?php
        $mysqli = new mysqli($Host,  $Usuario, $Senha, $Base);
        $sQuery = "select codigo, email, title_confirmacao, Title, tit_novo_chamado, tit_atu_chamado, tit1_list_chamado, tit_vis_chamado,
                  tit_rela_chamados, tit_novo_user, tit_novo_recado, tit_lista_recado, filtro_inicial
                    from layout
                    where  codigo like 1
                    order by codigo";
        $oUsers = $mysqli->query($sQuery);
        $oRow = $oUsers->fetch_object();
        
//acima select dos itens de configura��es do layout - abaixo select das cores para o objeto select do form..


?>


<?php
    include "config.php";
//    include "valida_user.inc";
?>

<html>
<head>
<title><?php echo $Title ?></title>
</head>

<body>

<form method="POST" action="save_cores_textos.php?op=texto">
<center>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="650">
  <tr>
    <td height="19" bgcolor="black"><Font face="Arial" size="2" color="white"><p align="center"><b>Configura��es de Textos, T�tulos e Op��es do Sistema.</b></td>
  </tr>
  <tr>
    <td height="19"></td>
  </tr>
  <tr>
    <td><font face="Verdana" size="1"><b>E-mails dos Administradores. Separe com ";" para adicionar mais que 1 endere�o.</b></td>
  </tr>
  <tr>
    <td><input type="text" name="T1" style="background-color: #99CCFF" size="104" value="<?php echo $oRow->email ?>"></td>
  </tr>
  <tr>
    <td><hr size="1" align="left" color="black" width="650"></td>
  </tr>
  
  <tr>
    <td><font face="Verdana" size="1"><b>T�tulo de Confirma��o na Tela de Logout (Nome da Empresa).</b></td>
  </tr>
  <tr>
    <td><input type="text" name="T2" size="104" value="<?php echo $oRow->title_confirmacao ?>"></td>
  </tr>
  <tr>
    <td><hr size="1" align="left" color="black" width="650"></td>
  </tr>
  
  <tr>
    <td><font face="Verdana" size="1"><b>T�tulo das P�ginas do Sistema.</b></td>
  </tr>
  <tr>
    <td><input type="text" name="T3" style="background-color: #99CCFF" size="104" value="<?php echo $oRow->Title ?>"></td>
  </tr>
  <tr>
    <td><hr size="1" align="left" color="black" width="650"></td>
  </tr>
  
  <tr>
    <td><font face="Verdana" size="1"><b>T�tulo do Formul�rio de Novo Chamado.</b></td>
  </tr>
  <tr>
    <td><input type="text" name="T4" size="104" value="<?php echo $oRow->tit_novo_chamado ?>"></td>
  </tr>
  <tr>
    <td><hr size="1" align="left" color="black" width="650"></td>
  </tr>

  <tr>
    <td><font face="Verdana" size="1"><b>T�tulo do Formul�rio de Altera��o de Chamado.</b></td>
  </tr>
  <tr>
    <td><input type="text" name="T5" style="background-color: #99CCFF" size="104" value="<?php echo $oRow->tit_atu_chamado ?>"></td>
  </tr>
  <tr>
    <td><hr size="1" align="left" color="black" width="650"></td>
  </tr>
  
  <tr>
    <td><font face="Verdana" size="1"><b>T�tulo do Formul�rio que lista os Chamados.</b></td>
  </tr>
  <tr>
    <td><input type="text" name="T6" size="104" value="<?php echo $oRow->tit1_list_chamado ?>"></td>
  </tr>
  <tr>
    <td><hr size="1" align="left" color="black" width="650"></td>
  </tr>
  
  <tr>
    <td><font face="Verdana" size="1"><b>T�tulo do Formul�rio de Visualiza��o detalhada do Chamado.</b></td>
  </tr>
  <tr>
    <td><input type="text" name="T7" style="background-color: #99CCFF" size="104" value="<?php echo $oRow->tit_vis_chamado ?>"></td>
  </tr>
  <tr>
    <td><hr size="1" align="left" color="black" width="650"></td>
  </tr>
  
  <tr>
    <td><font face="Verdana" size="1"><b>T�tulo do Formul�rio de Gera��o de Relat�rios.</b></td>
  </tr>
  <tr>
    <td><input type="text" name="T8" size="104" value="<?php echo $oRow->tit_rela_chamados ?>"></td>
  </tr>
  <tr>
    <td><hr size="1" align="left" color="black" width="650"></td>
  </tr>
  
  <tr>
    <td><font face="Verdana" size="1"><b>T�tulo do Formul�rio de Novo Usu�rio.</b></td>
  </tr>
  <tr>
    <td><input type="text" name="T9" style="background-color: #99CCFF" size="104" value="<?php echo $oRow->tit_novo_user ?>"></td>
  </tr>
  <tr>
    <td><hr size="1" align="left" color="black" width="650"></td>
  </tr>
  
  <tr>
    <td><font face="Verdana" size="1"><b>T�tulo do Formul�rio de Novo Recado.</b></td>
  </tr>
  <tr>
    <td><input type="text" name="T10" size="104" value="<?php echo $oRow->tit_novo_recado ?>"></td>
  </tr>
  <tr>
    <td><hr size="1" align="left" color="black" width="650"></td>
  </tr>
  
  <tr>
    <td><font face="Verdana" size="1"><b>T�tulo do Formul�rio da Lista de Recados.</b></td>
  </tr>
  <tr>
    <td><input type="text" name="T11" style="background-color: #99CCFF" size="104" value="<?php echo $oRow->tit_lista_recado ?>"></td>
  </tr>
  <tr>
    <td><hr size="1" align="left" color="black" width="650"></td>
  </tr>
  
  <tr>
    <td><font face="Verdana" size="1"><b>Filtro inicial para exibi��o dos chamados na "Rela��o de Chamados".</b></td>
  </tr>
  <tr>
    <td>
    <select size="1" name="T12">
    <option value="<?php echo $oRow->filtro_inicial ?>"><?php echo $oRow->filtro_inicial ?></option>
    <option value="Aberto">Aberto</option>
    <option value="Fechado">Fechado</option>
    <option value="Em Andamento">Em Andamento</option>
    <option value="">Todos</option>
    </select>
    </td>
  </tr>
  <tr>
    <td><hr size="1" align="left" color="black" width="650"></td>
  </tr>
  <tr>
    <td bgcolor="black" height="19"><Font face="Arial" size="1" color="white"><b>Altere as configura��es conforme os itens acima e clique em gravar configura��es.</b></td>
  </tr>

</table>
</center>
<p align="center"><input type="submit" value="Gravar Configura��es" name="B1"></p>
</form>
<center>
<table width="650">
<tr><td><center><?php include "bnt_layout.php" ?></center></td></tr>
</table>
</center>
</body>
</html>
