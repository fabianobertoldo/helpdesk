<?php
    include "config.php";
    include "layout.php";
?>

<!-- <HTML>
<HEAD>
<TITLE><?php echo $Title ?></TITLE>

</HEAD>

<BODY onload="document.form1.nome.focus()" bgcolor="#FFDAB9"<?php echo $cor_pagina ?>">
<td><center><img src="img/h2b.png"></center></td></br>
<td><center>
  <h1>FA&Ccedil;A SEU CHAMADO</h1></center></td></p>
<form name="form1" method="post" action="save_chamado_user.php" onSubmit="return validation();">
    <table bgcolor="<?php echo $cor_2 ?>" border="0" cellspacing="0" cellpadding="0" align="center" style="border-color: black; border-style: solid; border-width:1; font-family: verdana; font-size:10;">
        <tr>
            <td colspan="2" bgcolor="<?php echo $cor_bg_tit_campos ?>"><Font face="Arial" size="2" color="<?php echo $cor_titulos_form ?>"><p align="center"><b><?php echo $tit_novo_chamado ?></b></p></font></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>">&nbsp;</td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;</td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>Nome:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;&nbsp;<input type="text" maxlength="50" name="nome" size="50"></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>E-mail:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;&nbsp;<input type="text" maxlength="50" name="email" size="50"></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>Setor/Lojas:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;&nbsp;
            <select size="1" name="setor">
            <option value="LOJA01">LOJA01</option>
            
            </select></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>Tipo:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;
            <select size="1" name="tipo">
            <option value="Hardware">Hardware</option>
            <option value="Software">Software</option>
            <option value="Duvidas">D�vidas</option>
            <option value="Outros">Outros</option>
            </select></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>Descri��o do Problema:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;&nbsp;<textarea rows="5" cols="42" name="descricao"></textarea></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>Observa��o:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;&nbsp;<textarea rows="5" cols="42" maxlength="250" name="obs" size="120"></textarea></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>">&nbsp;</td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="2" bgcolor="<?php echo $cor_bg_tit_campos ?>"><p align="center">
            <input type = "submit" name="Submit" value ="Enviar">
            <input type="reset" name="limpar" value="Limpar"></p></td>
        </tr>
    </table>
    
<p align="center"><a href="http://www.oticagospel.com.br/helpdesk/consulta_status.php">Verifique seu Chamado</a><table width="500" border="0">
<tr>
<td><font face="verdana" size="2" color="<?php echo $cor_outros_textos ?>">Os campos com "*" s�o de preenchimento obrigat�rio.<br>Ao enviar o chamado, o mesmo ser� reportado ao Depto de Tecnologia, e uma c�pia ser� enviado para voc� no e-mail informado acima.</font></td>
</tr>
</table>
</form>
</BODY>
</HTML> -->


<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/style.css"> 
    <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
    
</head>
<body>

    <div class="container">    
    <center><img style="width: 30%;margin-top: 16px;margin-bottom: -30px" src="img/h2b.png"></center>
        <div id="loginbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
            <div class="panel panel-info" >
                    <div class="panel-heading">
                        <div class="panel-title">ABRIR CHAMADO</div>
                        
                    </div>     

                    <div style="padding-top:30px" class="panel-body" >

                        <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
                            
                        <form name="form1" method="post" action="save_chamado_user.php" id="loginform" class="form-horizontal" role="form">
                                    
                            <div style="margin-bottom: 25px" class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                <input id="login-username" type="text" class="form-control" name="nome" value="" placeholder="Informe seu nome">                                        
                            </div>
                                
                            <div style="margin-bottom: 25px" class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
                                <input id="login-password" type="email" class="form-control" name="email" placeholder="email da loja/setor/pessoal">
                            </div>
                            <div style="margin-bottom: 25px" class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-signal"></i></span>
                                <select class="form-control" size="1" name="setor">
                                    <option value="LOJA01">LOJA45</option>                                
                                </select>
                            </div>

                            <div style="margin-bottom: 25px" class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-tag"></i></span>
                                <select class="form-control" size="1" name="tipo" >
                                    <option value="Hardware">Escolha o motivo do chamado</option>
                                    <option value="Hardware">Computador</option>
                                    <option value="Software">Sistema</option>
                                    <option value="Duvidas">Telefone</option>
                                    <option value="Software">Bobinas</option>
                                    <option value="Outros">Outros</option>
                                </select>
                            </div>
                            <div style="margin-bottom: 25px" class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-text-width"></i></span>
                                <textarea class="form-control" rows="3" cols="42" name="descricao" placeholder="Descreva sua solicita��o" ></textarea>
                            </div>
                            <div style="margin-bottom: 25px" class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-text-width"></i></span>
                                <textarea class="form-control" rows="3" cols="42" name="obs" placeholder="Observa��es" ></textarea>
                            </div>

                            <div style="margin-top:10px" class="form-group">
                                    <!-- Button -->
                                <div class="col-sm-12 controls">
                                <input class="btn btn-success" type = "submit" name="Submit" value ="Enviar">
                            </div>
                        </form>     
                    </div>                     
                </div>  
            </div>
        </div> 
    </div>
</body>
</html>
