<?php

    include "config.php";
     include "layout.php";

    mysql_connect($Host, $Usuario, $Senha);
    mysql_select_db($Base);

$numero = ($HTTP_POST_VARS["numero"]);
$nome = ($HTTP_POST_VARS["nome"]);

    $sQuery = " select codigo, data_abertura, data_fecha, hora_abertura, hora_fecha, setor, ip, descricao, solucao, tipo, nome, email, status, obs
                from   chamados
                where codigo like '$numero' and nome like '$nome'
                order by codigo";
    $oUsers = mysql_query($sQuery);
    $num_registros = mysql_num_rows($oUsers);
    $oRow = mysql_fetch_object($oUsers);
?>

<html>
<head>
 <TITLE><?php echo $Title ?></TITLE>

</head>
<body style="font-family: verdana; font-size:11;" bgcolor="#FFDAB9">

<?php

if ($num_registros == 1) { ?>
  <div align="center">
  <center><font face="verdana" size="2">
  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="600">
    <tr><td background="img/h2blogo.png" height="70"></td></tr>
        </br></br>
    <tr>
      <td background="img/centro.jpg"><font face="verdana" size="2"><b>Codigo:</b> <?php echo $oRow->codigo ?></font></td>
    </tr>
    <tr><td background="img/centro.jpg">&nbsp;</td></tr>
    <tr>
      <td background="img/centro.jpg"><font face="verdana" size="2"><b>Data de Abertura:</b> <?php echo $oRow->data_abertura ?></font></td>
    </tr>
    <tr><td background="img/centro.jpg">&nbsp;</td></tr>
    <tr>
      <td background="img/centro.jpg"><font face="verdana" size="2"><b>Hora da Abertura:</b> <?php echo $oRow->hora_abertura ?></font></td>
    </tr>
    <tr><td background="img/centro.jpg">&nbsp;</td></tr>
    <tr>
      <td background="img/centro.jpg"><font face="verdana" size="2"><b>Setor:</b> <?php echo $oRow->setor ?></font></td>
    </tr>
    <tr><td background="img/centro.jpg">&nbsp;</td></tr>
    <tr>
      <td background="img/centro.jpg"><font face="verdana" size="2"><b>Descricao:</b> <?php echo $oRow->descricao ?></font></td>
    </tr>
    <tr><td background="img/centro.jpg">&nbsp;</td></tr>
    
      <td background="img/centro.jpg"><font face="verdana" size="2"><b>Tipo:</b> <?php echo $oRow->tipo ?></font></td>
    </tr>
    <tr><td background="img/centro.jpg">&nbsp;</td></tr>
    <tr>
      <td background="img/centro.jpg"><font face="verdana" size="2"><b>Nome:</b> <?php echo $oRow->nome ?></font></td>
    </tr>
    <tr><td background="img/centro.jpg">&nbsp;</td></tr>
    <tr>
      <td background="img/centro.jpg"><font face="verdana" size="2"><b>E-mail:</b> <?php echo $oRow->email ?></font></td>
    </tr>
    <tr><td background="img/centro.jpg">&nbsp;</td></tr>
    <tr>
      <td background="img/centro.jpg"><font face="verdana" size="2"><b>Status:</b> <?php echo $oRow->status ?></font></td>
    </tr>
        <tr><td background="img/centro.jpg">&nbsp;</td></tr>
        <tr>
      <td background="img/centro.jpg"><font face="verdana" size="2"><b>Solucao:</b> <?php echo $oRow->solucao ?></font></td>
    </tr>
    <tr><td background="img/centro.jpg">&nbsp;</td></tr>
    <tr>
    <tr>
      <td background="img/centro.jpg" ><font face="verdana" size="2"><b>Obs:</b> <?php echo $oRow->obs ?></font></td>
    </tr>
    <tr><td background="img/infer01.jpg">&nbsp;</td></tr>
  </table>
  </center>
</div>
    <?php
} else { ?>
   <div align="center">
   <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="650">
   <tr><td>Chamado n�o encontrado em nosso banco de dados, por favor verifique os dados.</td></tr>
   </table>
   </div> <?

    }


?>



</body>
</html>
