<?php
    date_default_timezone_set("America/Fortaleza");
    $date = date("d/m/y");
    $hora = date("H:i");
    include "config.php";
    include "valida_user.inc";
    include "layout.php";
?>




<!-- <HTML>
<HEAD>
<TITLE><?php echo $Title ?></TITLE>

</HEAD>

<BODY onload="document.form1.nome.focus()" bgcolor="#FFDAB9"<?php echo $cor_pagina ?>">
<td><center><img src="img/h2b.png"></center></td></br>
<td><center>
  <h1>FA&Ccedil;A SEU CHAMADO</h1></center></td></p>
<form name="form1" method="post" action="save_chamado_user.php" onSubmit="return validation();">
    <table bgcolor="<?php echo $cor_2 ?>" border="0" cellspacing="0" cellpadding="0" align="center" style="border-color: black; border-style: solid; border-width:1; font-family: verdana; font-size:10;">
        <tr>
            <td colspan="2" bgcolor="<?php echo $cor_bg_tit_campos ?>"><Font face="Arial" size="2" color="<?php echo $cor_titulos_form ?>"><p align="center"><b><?php echo $tit_novo_chamado ?></b></p></font></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>">&nbsp;</td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;</td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>Nome:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;&nbsp;<input type="text" maxlength="50" name="nome" size="50"></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>E-mail:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;&nbsp;<input type="text" maxlength="50" name="email" size="50"></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>Setor/Lojas:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;&nbsp;
            <select size="1" name="setor">
            <option value="LOJA01">LOJA01</option>
            
            </select></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>Tipo:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;
            <select size="1" name="tipo">
            <option value="Hardware">Hardware</option>
            <option value="Software">Software</option>
            <option value="Duvidas">D�vidas</option>
            <option value="Outros">Outros</option>
            </select></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>Descri��o do Problema:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;&nbsp;<textarea rows="5" cols="42" name="descricao"></textarea></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>Observa��o:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;&nbsp;<textarea rows="5" cols="42" maxlength="250" name="obs" size="120"></textarea></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>">&nbsp;</td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="2" bgcolor="<?php echo $cor_bg_tit_campos ?>"><p align="center">
            <input type = "submit" name="Submit" value ="Enviar">
            <input type="reset" name="limpar" value="Limpar"></p></td>
        </tr>
    </table>
    
<p align="center"><a href="http://www.oticagospel.com.br/helpdesk/consulta_status.php">Verifique seu Chamado</a><table width="500" border="0">
<tr>
<td><font face="verdana" size="2" color="<?php echo $cor_outros_textos ?>">Os campos com "*" s�o de preenchimento obrigat�rio.<br>Ao enviar o chamado, o mesmo ser� reportado ao Depto de Tecnologia, e uma c�pia ser� enviado para voc� no e-mail informado acima.</font></td>
</tr>
</table>
</form>
</BODY>
</HTML> -->


<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/style.css"> 
    <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
    <link href="./css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
    
</head>
<body>

    <div class="container">    

        <div id="loginbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
            <div class="panel panel-info" >
                    <div class="panel-heading">
                        <div class="panel-title">CHAMADO</div>
                        
                    </div>     

                    <div style="padding-top:30px" class="panel-body" >

                        <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>

                        <?php
                            if (!empty($_GET["id"])) {

                                
                                $sQuery = " select codigo, data_abertura, data_fecha, hora_abertura, hora_fecha, setor, ip, descricao, solucao, tipo, nome, email, status, obs
                                            from   chamados
                                            where  codigo = " . $_GET["id"];
                                $oUsers = $mysqli->query($sQuery);
                                $oRow = $oUsers->fetch_object();
                        ?>
                                                    
                        <form name="form1" method="post" action="<?php echo 'save_chamado_atu.php?op=alteracao&id='.$_GET["id"] ?>" id="loginform" class="form-horizontal" role="form">

                       
                            <div style="margin-bottom: 25px" class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                                <input type="text" class="form-control" name="data_abertura" title="Data da Abertura"  value="<?php echo $oRow->data_abertura ?>"> <span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
                                <input id="login-username" type="text" class="form-control" name="hora_abertura" title="Hora da Abertura"  value="<?php echo $oRow->hora_abertura ?>">                                        
                            </div>
                            
                            <div style="margin-bottom: 25px" class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-signal"></i></span>
                                <input type="text" class="form-control" name="setor" title="Setor"  value="<?php echo $oRow->setor ?>" >
                                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                <input type="text" class="form-control" name="nome" title="Nome"  value="<?php echo $oRow->nome ?>" >
                                <span class="input-group-addon"><i class="glyphicon glyphicon-globe"></i></span>
                                <input title="Ip" type="text" class="form-control" name="ip" value="<?php echo $oRow->ip ?>" >                                        
                            </div>                         
                                
                            <div style="margin-bottom: 25px" class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-text-width"></i></span>
                                <textarea placeholder="Descri��o" title="Descri��o" class="form-control"  
                                name="descricao"><?php echo $oRow->descricao ?></textarea>             
                            </div>

                            <div style="margin-bottom: 25px" class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-tag"></i></span>
                                <select  title="Tipo de chamado" class="form-control" size="1" name="tipo" >
                                    <option value="<?php echo $oRow->tipo ?>"> <?php echo $oRow->tipo ?></option>
                                    <option value="Saldo de lentes/alian�as"> Saldo de lentes\alian�as</option>
                                    <option value="Computador">Computador</option>
                                    <option value="Sistema">Sistema</option>
                                    <option value="Impressora">Impressora/toner</option>
                                    <option value="Telefonia">Telefonia</option>
                                    <option value="C�meras">C�meras</option>
                                    <option value="D�vidas">D�vidas</option>
                                    <option value="Outros">Outros</option>
                                </select>
                                <span class="input-group-addon"><i class="glyphicon glyphicon-text-width"></i></span>
                                <select  value="<?php echo $oRow->status ?>"  title="Status do Chamado" class="form-control" size="1" name="status" >
                                    <option value="<?php echo $oRow->status?>"> <?php echo $oRow->status ?></option>
                                    <option value="Aberto">Aberto</option>
                                    <option value="Fechado">Fechado</option>
                                    <option value="Em andamento">Em andamento</option>
                                </select>
                            </div>
                            <div style="margin-bottom: 25px" class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-text-width"></i></span>
                                <textarea title="Solu��o" class="form-control" rows="3" cols="42" name="solucao" placeholder="Solu��o" ><?php echo $oRow->solucao ?></textarea>
                            </div>

                            <div style="margin-bottom: 25px" class="input-group">
                                
                            </div>

                            <div style="margin-top:10px" class="form-group">
                                <div class="col-sm-12 controls">
                                <input class="btn btn-success" type = "submit" name="Submit" value ="Enviar">
                            </div>
                        </form>     
                        <?php 
                        }else{


                        }?>
                    </div>                     
                </div>  
            </div>
        </div> 
    </div>
</body>
</html>
