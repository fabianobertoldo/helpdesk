<?php

    include "config.php";
    include "layout.php";
    $ip = getenv("REMOTE_ADDR");

    $filtro = ($_POST["filtro"]);
    $consulta = ($_POST["consulta"]);
    $status = ($_POST["status"]);

    $sQuery = " select codigo, data_abertura, data_fecha, hora_abertura, hora_fecha, setor, ip, descricao, solucao, tipo, nome, status, obs
                from   chamados
                where $filtro like '$consulta%' and status like '$status%' and ip = '$ip'
                order by codigo desc";
    $oUsers = $mysqli->query($sQuery);
    $num_registros = $oUsers->num_rows;
?>

<script>
    function excluir(id){
        if (confirm('Confirmar Exclus�o?')){
            window.location = 'delete_chamado.php?id='+id
    	}
    }
    function alterar(id){
        window.location = 'novo_chamado.php?id='+id;
    }
    function visualizar(id){
        window.location = 'visu_chamado.php?id='+id;
    }
</script>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
 <TITLE><?php echo $Title ?></TITLE>
<link rel="stylesheet" type="text/css" href="./css/style.css"> 
<link rel="stylesheet" type="text/css" href="./css/normalize.css"> 
<link rel="stylesheet" type="text/css" href="./css/print.css" media="print" > 


</head>
<body>

<table class="responstable">
  
  <tr>
    <th width="20" colspan="3">&nbsp;</td>
    <th width="30"><font style="COLOR: #f2f2f2;
" size="1" face="verdana" color="#000000"<?php echo $cor_titulos_campos ?>"><center>C�DIGO</center></font></th>
    <th width="70"><font style="
    COLOR: #f2f2f2;
" size="1" face="verdana" color="#000000"<?php echo $cor_titulos_campos ?>"><center>DT. ABERT.</center></font></th>
    <th width="70"><font style="
    COLOR: #f2f2f2;
" size="1" face="verdana" color=" #000000"<?php echo $cor_titulos_campos ?>"><center>HR ABERTURA.</center></font></th>
    <th width="150"><font style="
    COLOR: #f2f2f2;
" size="1" face="verdana" color=" #000000"<?php echo $cor_titulos_campos ?>"><center>SETOR</center></font></td>
    <th width="130%"><font style="
    COLOR: #f2f2f2;
" size="1" face="verdana" color=" #000000"<?php echo $cor_titulos_campos ?>"><center>DESC. PROBLEMA</center></font></th>
    <th width="50"><font style="
    COLOR: #f2f2f2;
" size="1" face="verdana" color=" #000000"<?php echo $cor_titulos_campos ?>"><center>TIPO</center></font></th>
    <th width="160"><font style="
    COLOR: #f2f2f2;
" size="1" face="verdana" color=" #000000"<?php echo $cor_titulos_campos ?>"><center>NOME</center></font></th>
    <th width="100"><font style="
    COLOR: #f2f2f2;
" size="1" face="verdana" color=" #000000"<?php echo $cor_titulos_campos ?>"><center>STATUS</center></font></th>
  </tr>
        <?php

   
        while ($oRow = $oUsers->fetch_object()){              

                
          // $oRow->data_abertura = converteData($oRow->data_abertura);


            echo "<tr >
                      <td align=\"center\"><a href=\"#\" onClick=\"excluir('". $oRow->codigo . "')\"><img src=\"img/excluir.jpg\" alt=\"Excluir\" width=\"15\" height=\"16\" border=\"0\"></a></td>
                      <td align=\"center\"><a href=\"#\" onClick=\"alterar('". $oRow->codigo  ."')\"><img src=\"img/alterar.jpg\" alt=\"Alterar\" width=\"15\" height=\"16\" border=\"0\"></a></td>
                      <td align=\"center\"><a href=\"#\" onClick=\"visualizar('". $oRow->codigo ."')\"><img src=\"img/ver.jpg\" alt=\"Visualizar\" width=\"15\" height=\"16\" border=\"0\"></a></td>
                      <td><center><a href=\"#\" onClick=\"alterar('". $oRow->codigo ."')\" style=\"text-decoration: none\"><font color=\"$cor_dados\">$oRow->codigo</font></center></td>
                      <td><center><a href=\"#\" onClick=\"alterar('". $oRow->codigo ."')\" style=\"text-decoration: none\"><font color=\"$cor_dados\">
$oRow->data_abertura   </font></center></td>
                      <td><center><a href=\"#\" onClick=\"alterar('". $oRow->codigo ."')\" style=\"text-decoration: none\"><font color=\"$cor_dados\">$oRow->hora_abertura</font></center></td>
                      <td><center><a href=\"#\" onClick=\"alterar('". $oRow->codigo ."')\" style=\"text-decoration: none\"><font color=\"$cor_dados\">$oRow->setor</font></center></td>
                      <td><center><a href=\"#\" onClick=\"alterar('". $oRow->codigo ."')\" style=\"text-decoration: none\"><font color=\"$cor_dados\">$oRow->descricao</font></center></td>
                      <td><center><a href=\"#\" onClick=\"alterar('". $oRow->codigo ."')\" style=\"text-decoration: none\"><font color=\"$cor_dados\">$oRow->tipo</font></center></td>
                      <td><center><a href=\"#\" onClick=\"alterar('". $oRow->codigo ."')\" style=\"text-decoration: none\"><font color=\"$cor_dados\">$oRow->nome</font></a></center></td>
                      <td><center><a href=\"#\" onClick=\"alterar('". $oRow->codigo ."')\" style=\"text-decoration: none\"><font color=\"$cor_dados\">$oRow->status</font></center></td>
                  </tr>";
        }
        ?>
    </table ><p>

    <p>

</body>
</html>