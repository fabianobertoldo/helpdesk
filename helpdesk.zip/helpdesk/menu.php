<?php
    ini_set('default_charset','UTF-8');
    include "config.php";
    include "valida_user.inc";
    include "layout.php";
    date_default_timezone_set("America/Fortaleza");
    $date = date("d/m/y");
    $hora = date("H:i");
?>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title><?php echo $Title ?></title>
        <link rel="stylesheet" type="text/css" href="./css/style.css"> 
        <link rel="stylesheet" type="text/css" href="./css/normalize.css"> 
        <link rel="stylesheet" type="text/css" href="./css/print.css" media="print" > 
        <base target="principal">
    </head>

    <body bgcolor="#FFDAB9">
        <table class="responstable" style=" margin-top: 0;border-left-width: 14px;">
            <tr>
                <td>
                    <img src="img/bnt_rel_chamados.jpg">
                </td>
                <td>
                    <a target="principal"  href="lista_chamados_geral.php">
            		    Relacão de Chamados
            	    </a>
                </td>
            </tr>
            <tr>
                <td>
                	<img border="0" src="img/bnt_abrir_cha.jpg" width="30" height="30">
                </td>
                <td>
                	<a target="principal" href="chamado_user01.php" style="text-decoration: none">
               		    Abrir Chamado
               	    </a>
                </td>
            </tr>
            <tr>
                <td>
                	<img border="0" src="img/bnt_estatis.jpg" width="30" height="30">
                </td>
                <td>
                	<a target="principal" href="estatistica.php" style="text-decoration: none">
                		Estatísticas
                	</a>
                </td>    
            </tr>
            <tr>
                <td>
                	<img border="0" src="img/bnt_rela_chamados.jpg" width="30" height="30">
                </td>
                <td>
                	<a target="principal" href="tipo_rela.php" style="text-decoration: none">
               		    Rel. de Chamados
               	    </a>
                </td>    
            </tr>
            <tr>
                <td>
                	 <img border="0" src="img/bnt_cad_usuario.jpg" width="30" height="30">
                </td>
                <td>
                	<a target="principal" href="novo_user.php" style="text-decoration: none">
               		Cadastro de Usuarios
               	</a>
                </td>    
            </tr>
            <tr>
                <td>
                	  <img border="0" src="img/bnt_cad_usuario.jpg" width="30" height="30">
                </td>
                <td>
                	<a target="principal" href="listar_user.php" style="text-decoration: none">
                    	Usuários Cadastrados
                    </a>
                </td>    
            </tr>
            <!-- <tr>
                <td>
                	  <img border="0" src="img/bnt_recados.jpg" width="30" height="30">
                </td>
                <td>
                	<a target="principal" href="novo_recado.php" style="text-decoration: none">
                		Adicionar Recado
                	</a>
                </td> 
            </tr> 
            <tr>
                <td>
                	   <img border="0" src="img/bnt_config_lay.jpg" width="30" height="30">
                </td>
                <td>
                	<a target="principal" href="altera_cor.php" style="text-decoration: none">
              	    	Config. do Layout
              	    </a>
                </td>    
            </tr>-->
            <tr>
                <td>
                	    <img border="0" src="img/bnt_sobre.jpg" width="30" height="30">
                </td>
                <td>
                	<a target="principal" href="backup.php" style="text-decoration: none">
                		Backup
                	</a>
                </td>    
            </tr>
            <tr>
                <td>
                	    <img border="0" src="img/bnt_logout.jpg" width="30" height="30">
                </td>
                <td>
                	<a target="_top" href="logout.php" style="text-decoration: none">
               		Logout do Sistema
               	</a>
                </td>    
            </tr>
        </table>
    <!--<script src='http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js'></script> -->
    </body>
</html>
