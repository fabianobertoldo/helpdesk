<?php
    ini_set('default_charset','UTF-8');
    date_default_timezone_set("America/Fortaleza");
    function inverteData($data){
        if(count(explode("/",$data)) > 1){
            return implode("-",array_reverse(explode("/",$data)));
        }elseif(count(explode("-",$data)) > 1){
            return implode("/",array_reverse(explode("-",$data)));
        }
    }
    include "config.php";
    include "valida_user.inc";
    include "layout.php";
    define('MPDF_PATH', 'mpdf60/');
    
    $setor = ($_POST["setor"]);
    $dataInicial = ($_POST["dataInicial"]);
    $dataInicial = implode("/",array_reverse(explode("/", $dataInicial)));
    $dataFinal = ($_POST["dataFinal"]);
    $dataFinal = implode("/",array_reverse(explode("/", $dataFinal)));
    $dataInicial = date($dataInicial);
    $dataFinal = date($dataFinal);

    $mysqli = new mysqli($Host,  $Usuario, $Senha, $Base);
    $sQuery = "select codigo, setor, ip, descricao,hora_abertura,data_abertura, solucao, tipo, nome, status, obs 
               from chamados 
               where setor like '$setor%' and data_abertura >= '$dataInicial' and data_abertura <=' $dataFinal'
               order by codigo desc";   
    $oUsers = $mysqli->query($sQuery);
    $num_registros = $oUsers->num_rows;
  
?>

<html>

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <TITLE>Relatório de Chamados por Setor definido como: <?php echo $setor ?></TITLE>
        <link rel="stylesheet" type="text/css" href="./css/style.css"> 
        <link rel="stylesheet" type="text/css" href="./css/normalize.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
        
    </head>
    <body style="font-size: 11px;">
        </br>
        </br>
        <h2>Relatório de Chamados por Setor definido como: <span><?php if(empty($setor)) echo "Todos os Setores";    else echo $setor; ?></span></h2>
        <h2>Período consultado:<span><?php if (empty($dataInicial)) {
               echo "00/00/00";
             } else {echo $dataInicial;} ?> </span> até<span> <?php if(empty($dataFinal)) {echo $date;}  else{echo $dataFinal;} ?></span></h1>
             
             
             
             
        <table id="table_id" class="display">
            <thead>
                <tr>
                    <th>Cod. Chamado</th>
                    <th>Setor/Loja</th>
                    <th>Data de Abertura</th>
                    <th>Descrição</th>
                    <th>Solução</th>
                    <th>Tipo de Chamado</th>
                    <th>Nome</th>
                </tr>
            </thead>
            <tbody>
            
            <?php
                while ($oRow = $oUsers->fetch_object()) {
                    echo "<tr>
                              <td style='width: 10px'><font face=\"arial\" size=\"2\"><center>$oRow->codigo</font></center></td>
                              <td><font face=\"arial\" size=\"2\"><center>$oRow->setor</font></center></td>
                              <td><font face=\"arial\" size=\"2\"><center>$oRow->data_abertura</font></center></td>
                              <td class='descricao' style='width: 40%'><font face=\"arial\" size=\"2\">$oRow->descricao</font></td>
                              <td class='solucao'><font face=\"arial\" size=\"2\">$oRow->solucao</font></td>
                              <td><font face=\"arial\" size=\"2\"><center>$oRow->tipo</font></center></td>
                              <td><font face=\"arial\" size=\"2\"><center>$oRow->nome</font></center></td>
                          </tr>";
                }
            ?>            
                
            </tbody>
        </table>
        <h2>
            Total de chamados: 
            <span> 
                <?php echo $num_registros ?> 
            </span>
            </br>
            Relatóio emitido em 
            <span>
                <?php echo $date = date('d-m-Y')?> 
            </span> 
            ás 
            <span>
                <?php echo $date = date('H:i') ?>
            </span>
            , pelo usuáio 
            <span> 
                <?php echo $nome_usuario ?>
            </span>
        </h2>
    </body>
    <script>
        $(document).ready( function () {
            $('#table_id').DataTable({
                    paging: false,
                    scrollY: 400

            });
        } );
    </script>
</html>