<!DOCTYPE html>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
  <title>Sistema de Controle</title>
  <link rel="stylesheet" type="text/css" href="./css/style.css"> 
  <link rel="stylesheet" type="text/css" href="./css/normalize.css"> 
  <link rel="stylesheet" type="text/css" href="./css/print.css" media="print" > 
  <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
  <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<meta charset="utf-8"></meta>
</head>

<body onload="document.form1.username.focus()" bgcolor="#FFDAB9">
<!-- 
<p>&nbsp;</p>
<p>&nbsp;</p>
<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" bgcolor="#024457" style="border-collapse: collapse; border: 1px solid silver" bordercolor="#111111" width="500">
    <tr>
      <td width="50" height="50">&nbsp;</td>
      <td height="50" width="420">&nbsp;</td>
      <td width="50" height="50">&nbsp;</td>
    </tr>
    <tr>
      <td width="50" height="205">&nbsp;</td>
      <td width="420" height="205">
<form name="form1" method="POST" action="login.php">
<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="400" height="205" background="img/logon2.png">
    <tr>
      <td>
      <div align="center">
        <center>
        <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="390">
          <tr>
            <td width="85">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td width="145">&nbsp;</td>
          </tr>
          <tr>
            <td width="85">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td width="145">&nbsp;</td>
          </tr>
          <tr>
            <td width="85">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td width="145">&nbsp;</td>
          </tr>
          <tr>
            <td width="85"><font face="verdana" size="1" color="silver"><b>Usu�rio:</b></td>
            <td width="160"><input type="text" name="username" size="20" tabindex="1"></td>
            <td width="145"><input style="background: #167F92;
    border: none;
    color: white;
    font-size: 12px;
    padding: 4px;
    border-radius: 2px;"type="submit" value="ENTRAR" name="B1" tabindex="3"></td>
          </tr>
          <tr>
            <td width="85"><font face="verdana" size="1" color="silver"><b><span>Senha:</span></b></td>
            <td width="160"><input type="password" name="senha" size="20" tabindex="2"></td>
            <td width="145"><input style="background: #167F92;
    border: none;
    color: white;
    font-size: 12px;
    padding: 4px;
    border-radius: 2px;" type="reset" value="LIMPAR" name="B2" tabindex="4"></td>
          </tr>
          <tr>
            <td width="85">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td width="145">&nbsp;</td>
          </tr>
          <tr>
            <td width="85">&nbsp;</td>
            <td width="160">&nbsp;</td>
            <td width="145">&nbsp;</td>
          </tr>
          <tr>
            <td width="390" colspan="3"><font face="verdana" size="1" color="silver"><b>Entre com o nome de usu�rio e senha para efetuar o login no sistema.</b></td>
          </tr>
        </table>
        </center>
      </div>
      </td>
    </tr>
  </table>
  </center>
</div>
</form>
      </td>
      <td width="50" height="205">&nbsp;</td>
    </tr>
    <tr>
      <td width="50" height="50">&nbsp;</td>
      <td height="50" width="420">&nbsp;</td>
      <td width="50" height="50">&nbsp;</td>
    </tr>
  </table>
  </center>
</div> -->

    <div class="container">    
        <div id="loginbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
            <div class="panel panel-info" >
            <center><img style="width: 74%;" src="img/h2b.png"></center>
                    <div class="panel-heading">
                        <div class="panel-title">Faça Login</div>
                        
                    </div>     

                    <div style="padding-top:30px" class="panel-body" >

                        <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
                            
                        <form name="form1" method="POST" action="login.php" id="loginform" class="form-horizontal" role="form">
                                    
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                        <input id="login-username" type="text" class="form-control" name="username" value="" placeholder="Nome de usu�rio">                                        
                                    </div>
                                
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                        <input id="login-password" type="password" class="form-control" name="senha" placeholder="password">
                                    </div>
                                    

                                
                             <div style="margin-top:10px" class="form-group">
                                    <!-- Button -->

                                    <div class="col-sm-12 controls">
                                      <input type="submit" value="ENTRAR" name="B1"  id="btn-login"  class="btn btn-success"></input>
                                     

                                    </div>
                                </div>


                               
                            </form>     



                        </div>                     
                    </div>  
        </div>
        
               
               
                
         </div> 
    </div>


</body>

</html>

