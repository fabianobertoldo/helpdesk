<?php
     include "config.php";
     include "valida_user.inc";
     include "layout.php";
?>

<html>

<head>
<title><?php echo $Title ?></title>
<link rel="stylesheet" type="text/css" href="./css/style.css"> 
<link rel="stylesheet" type="text/css" href="./css/normalize.css"> 
<link rel="stylesheet" type="text/css" href="./css/print.css" media="print" > 
</head>

<body bgcolor="#FFDAB9"<?php echo $cor_pagina ?>">

<p align="center"><img style="   width: 273px;    margin: 65px 0 0 -188px;" src="img/gospel.png"/></p>


</body>

</html>
