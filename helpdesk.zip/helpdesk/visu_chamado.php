<?php

    include "config.php";
    include "valida_user.inc";
     include "layout.php";
?>

<html>
<head>
 <TITLE><?php echo $Title ?></TITLE>
</head>
<body bgcolor="#FFDAB9"<?php echo $cor_pagina ?>">

<?php
    if (!empty($HTTP_GET_VARS["id"])) {

       
       $mysqli = new mysqli($Host,  $Usuario, $Senha, $Base);
        $sQuery = " select codigo, data_abertura, data_fecha, hora_abertura, hora_fecha, setor, ip, descricao, solucao, tipo, nome, email, status, obs, tecnico
                    from   chamados
                    where  codigo = " . $_GET["id"];
        $oUsers = $mysqli->query($sQuery);
        $oRow =$oUsers->fetch_object();
?>



<td><center><h1>CHAMADO</h1></center></td>
<form name="form1" method="post" action="<?php echo 'save_proce.php?op=alteracao&id='.$HTTP_GET_VARS["id"] ?>">
<div align="center">
  <center>
  <table width="650" border="2" cellspacing="1" cellpadding="0" align="center" style="border-color: #000000; border-style: solid; border-width:1;" bordercolor="#111111">
    <tr>
      <td colspan="5" bgcolor="<?php echo $cor_bg_tit_campos ?>"><Font face="Arial" size="2" color="<?php echo $cor_titulos_form ?>"><p align="center"><b><?php echo $tit_vis_chamado ?></b></p></font></td>
	</tr>
    <tr>
      <td width="130" bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>">Codigo</font></td>
      <td width="130" bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>">Dt. Abert.
      </font></td>
      <td width="130" bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>">Hr. Abert.</font></td>
      <td width="130" bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>">Dt. Fecham.</font></td>
      <td width="130" bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>">Hr. Fecham.</font></td>
    </tr>
    <tr>
      <td width="130" bgcolor="<?php echo $cor_bg_dados_inputs ?>" align="center"><font face="Arial" size="2" color="<?php echo $cor_dados ?>"><?php echo $oRow->codigo ?></font></td>
      <td width="130" bgcolor="<?php echo $cor_bg_dados_inputs ?>" align="center"><font face="Arial" size="2" color="<?php echo $cor_dados ?>"><?php echo $oRow->data_abertura ?></font></td>
      <td width="130" bgcolor="<?php echo $cor_bg_dados_inputs ?>" align="center"><font face="Arial" size="2" color="<?php echo $cor_dados ?>"><?php echo $oRow->hora_abertura ?></font></td>
      <td width="130" bgcolor="<?php echo $cor_bg_dados_inputs ?>" align="center"><font face="Arial" size="2" color="<?php echo $cor_dados ?>"><?php echo $oRow->data_fecha ?></font></td>
      <td width="130" bgcolor="<?php echo $cor_bg_dados_inputs ?>" align="center"><font face="Arial" size="2" color="<?php echo $cor_dados ?>"><?php echo $oRow->hora_fecha ?></font></td>
    </tr>
    <tr>
      <td width="130" bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center">&nbsp;</td>
      <td width="130" bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>">Ip</font></td>
      <td width="130" bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center">&nbsp;</td>
      <td width="130" bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>">Tipo</font></td>
      <td width="130" bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center">&nbsp;</td>
    </tr>
    <tr>
      <td width="130" bgcolor="<?php echo $cor_bg_dados_inputs ?>" align="center">&nbsp;</td>
      <td width="130" bgcolor="<?php echo $cor_bg_dados_inputs ?>" align="center"><font face="Arial" size="2" color="<?php echo $cor_dados ?>"><?php echo $oRow->ip ?></font></td>
      <td width="130" bgcolor="<?php echo $cor_bg_dados_inputs ?>" align="center">&nbsp;</td>
      <td width="130" bgcolor="<?php echo $cor_bg_dados_inputs ?>" align="center"><font face="Arial" size="2" color="<?php echo $cor_dados ?>"><?php echo $oRow->tipo ?></font></td>
      <td width="130" bgcolor="<?php echo $cor_bg_dados_inputs ?>" align="center">&nbsp;</td>
    </tr>

  </table>
  </center>
</div>

<div align="center">
  <center>
  <table width="650" border="0" cellspacing="1" cellpadding="0" align="center" style="border-color: #000000; border-style: solid; border-width:2;" bordercolor="#111111">
    <tr>
      <td bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>">Setor</font></td>
      <td bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>">Nome</font></td>
      <td bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>">E-Mail</font></td>
      <td bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>">Status</font></td>
    </tr>
    <tr>
      <td width="150" bgcolor="<?php echo $cor_bg_dados_inputs ?>" align="center"><font face="Arial" size="2" color="<?php echo $cor_dados ?>"><?php echo $oRow->setor ?></font></td>
      <td width="180" bgcolor="<?php echo $cor_bg_dados_inputs ?>" align="center"><font face="Arial" size="2" color="<?php echo $cor_dados ?>"><?php echo $oRow->nome ?></font></td>
      <td width="250" bgcolor="<?php echo $cor_bg_dados_inputs ?>" align="center"><font face="Arial" size="2" color="<?php echo $cor_dados ?>"><?php echo $oRow->email ?></font></td>
      <td width="60" bgcolor="<?php echo $cor_bg_dados_inputs ?>" align="center"><font face="Arial" size="2" color="<?php echo $cor_dados ?>"><?php echo $oRow->status ?></font></td>
    </tr>
  </table>
  </center>
</div>

<div align="center">
  <center>
  <table border="2" cellspacing="1" cellpadding="1" align="center" style="border-color: #000000; border-style: solid; border-width:1;" bordercolor="#111111" width="650">
    <tr>
      <td bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center">
      <p align="left"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>">Descri��o</font></td>
    </tr>
    <tr>
      <td bgcolor="<?php echo $cor_bg_dados_inputs ?>" align="center">
      <p align="left"><font face="Arial" size="2" color="<?php echo $cor_dados ?>"><?php echo $oRow->descricao ?></font></td>
    </tr>
    <tr>
      <td bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center">
      <p align="left"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>">Solu��o</font></td>
    </tr>
    <tr>
      <td bgcolor="<?php echo $cor_bg_dados_inputs ?>" align="center">
      <p align="left"><font face="Arial" size="2" color="<?php echo $cor_dados ?>"><?php echo $oRow->solucao ?></font></td>
    </tr>
    <tr>
      <td bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center">
      <p align="left"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>">Observa��o</font></td>
    </tr>
    <tr>
      <td bgcolor="<?php echo $cor_bg_dados_inputs ?>"><font face="Arial" size="2" color="<?php echo $cor_dados ?>"><?php echo $oRow->obs ?></font></td>
    </tr>
    <tr>
      <td bgcolor="<?php echo $cor_bg_tit_campos ?>" align="center">
      <p align="left"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>">T�cnico Respons�vel</font></td>
    </tr>
    <tr>
      <td bgcolor="<?php echo $cor_bg_dados_inputs ?>"><font face="Arial" size="2" color="<?php echo $cor_dados ?>"><?php echo $oRow->tecnico ?></font></td>
    </tr>
    
  </table>
  </center>
</div>
</form>


<?php
    } else {
?>

<?php
    }
?>

<p>
<table border="0" align="center" width="650">
<tr><td>
<?php include "bnt_voltar.htm" ?>
</td></tr>
</table>

</body>
</html>
