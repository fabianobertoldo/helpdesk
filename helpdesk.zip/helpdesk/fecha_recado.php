<?php
    include "config.php";
    include "valida_user.inc";
     include "layout.php";
    mysql_connect($Host, $Usuario, $Senha);
    mysql_select_db($Base);

      $sQuery = "update recados set
                         concluido = '" . "s" . "'
                 where codigo = " . $HTTP_GET_VARS["id"];

                 mysql_query($sQuery);
//                 echo "<script>window.location='lista_recados.php'</script>";

//aqui em cima o sistema altera o status do campo comclu�do para Sim (s)
?>

<?php

    mysql_connect($Host, $Usuario, $Senha);
    mysql_select_db($Base);

    $sQuery_recado = " select concluido
                from recados
                where concluido like 'n%' and user_from like '$nome_usuario'";
    $oUsers_recado = mysql_query($sQuery_recado);
    $num_registros_recado = mysql_num_rows($oUsers_recado);
    $oRow_recado = mysql_fetch_object($oUsers_recado);
    

    if ($num_registros_recado > 0) { ?>
        <script>
        window.open('lista_recados.php','envio','scrollbars=yes,width=810,height=250');
        </script>
     <?

    } else { ?>
        <script>
        window.close();
        </script>
        <?

    }

?>





<HTML>
<HEAD>
 <TITLE>Documento PHP</TITLE>
</HEAD>
<BODY>
<?

?>
</BODY>
</HTML>
