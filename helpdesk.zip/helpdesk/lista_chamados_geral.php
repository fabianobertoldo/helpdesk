<?php
    ini_set('default_charset','UTF-8');
    include "config.php";
    include "valida_user.inc";
    include "layout.php";
?>
<!DOCTYPE html>
<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        
        <title><?php echo $Title ?></title>
    </head>
    <frameset framespacing="0" border="0" frameborder="0" rows="70,*">
        <frame name="cabe�alho" scrolling="no" noresize target="principal" src="envia_consulta.php"> 
        <frame name="principal_2" src="listar_chamado.php">
        <noframes>
        <body>
          <p>Esta p�gina usa quadros mas seu navegador n�o aceita quadros.</p>
        </body>
        </noframes>
    </frameset>
</html>
