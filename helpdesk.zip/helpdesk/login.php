<?php
    date_default_timezone_set('America/Sao_Paulo');
    include "config.php";
    $date = date("d/m/y");
    $hora = date("H:i");
    
    @session_start(); // Inicializa a sess�o
    
    $mysqli = new mysqli($Host,  $Usuario, $Senha, $Base);

    /* check connection */
    if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
    }

    $user = $_POST["username"];
    $pwd  = $_POST["senha"];
    
    $sQuery = "select cod_usuario, nom_usuario, login, pwd_usuario, nivel
               from   usuarios
               where  login = '" . $user . "'";
    $oUser = $mysqli->query($sQuery)
             or die("Query invalida: " . mysqli_error());
             
    $row = $oUser->fetch_object();
    if ($num_rows = $oUser->num_rows == 1) {
        if ($row->pwd_usuario == $pwd) {
            if ($row->nivel == $Nivel) {
               $_SESSION["log_usuario"] = $user;
               $_SESSION["pwd_usuario"] = $pwd;
               $_SESSION["nom_usuario"] = $row->nom_usuario;
               $_SESSION["cod_usuario"] = $row->cod_usuario;
///////////////////////grava o acesso ao sistema na tabela acesso.
               $sQuery1 = "insert into acesso (cod_user, nome_user, data, hora)
                 values ('" . $row->cod_usuario . "',
                         '" . $user . "',
                         '" . $date . "',
                         '" . $hora  . "')";
               $mysqli->query($sQuery1);
               echo "<script>window.location='index_2.php'</script>";
            } else {
                   ?>
                   <script language="JavaScript">
                   <!--
                   alert("Nivel acesso incorreto!");
                   window.location = 'index.php';
                   //-->
                   </script>
                <?php
                }
        } else {
            ?>
                <script language="JavaScript">
                <!--
                alert("Senha incorreta!");
                window.location = 'index.php';
                //-->
                </script>
            <?php
        }
    } else {
        ?>
            <script language="JavaScript">
            <!--
            alert("Usu�rio n�o encontrado!");
            window.location = 'index.php';
            //-->
            </script>
        <?php
    }
?>
