<?php
    ini_set('default_charset','UTF-8');
    date_default_timezone_set("America/Fortaleza");
    include "config.php";
    include "valida_user.inc";
    include "layout.php";
    
    $date = date("d/m/y");
    $hora = date("H:i");
    
    //contador de vezes que o usuario acessou o sistema...
    $mysqli = new mysqli($Host,  $Usuario, $Senha, $Base);
    $sQuery = " select nome_user
                from   acesso
                where nome_user like '$nome_usuario'
                order by nome_user";
    $result = $mysqli->query($sQuery);
    $num_registros = $result->num_rows;

// fim  ?>
<!DOCTYPE html>
<html>
    <head>
        
        <title>HelpDesk H2B</title>
        <meta equiv="refresh" content="5"></meta>
        <?php echo "<script>window.defaultStatus='Seja Bem Vindo(a) $nome_usuario. Voc� est� logado desde as $hora hrs. Acesso n�mero $num_registros.'</script>" ?>
        <link rel="stylesheet" type="text/css" href="./css/style.css"> 
        <link rel="stylesheet" type="text/css" href="./css/normalize.css"> 
        <link rel="stylesheet" type="text/css" href="./css/print.css" media="print" > 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    </head>
    
    <frameset framespacing="0" border="0" frameborder="0" rows="92,*">
        <frame name="faixa" scrolling="no" noresize target="conte�do" src="superior.php">
        <frameset cols="260,*">
        <frame name="conte�do" target="principal" src="menu.php" scrolling="auto">
        <frame name="principal" src="corpo_do_sistema.php" scrolling="auto">
    </frameset>
    <noframes>
        
    <body>
        <p>Esta p�gina usa quadros mas seu navegador n�o aceita quadros.</p>
    
        <div style="width: 300px; height: 300px; background: yellow" onclick="notify()">
            Clique aqui para a notifica��o
        </div>
        
        <script>
            function notify() {
                Notification.requestPermission(function() {
                    var notification = new Notification("T�tulo", {
                        icon: 'http://i.stack.imgur.com/dmHl0.png',
                        body: "Texto da notifica��o"
                    });
                    notification.onclick = function() {
                        window.open("http://stackoverflow.com");
                    }
                });
            }  
        </script>
    </body>
  </noframes>
</html>
