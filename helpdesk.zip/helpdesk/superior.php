<?php
    ini_set('default_charset','UTF-8');
    include "config.php";
    include "valida_user.inc";
    include "layout.php";

    $mysqli = new mysqli($Host,  $Usuario, $Senha, $Base);
    $sQuery_recado = " select concluido
                from recados
                where concluido like 'n%' and user_from like '$nome_usuario'";
    $oUsers_recado = $mysqli->query($sQuery_recado);
    $num_registros_recado = $oUsers_recado->num_rows;
    $oRow_recado = $oUsers_recado->fetch_object();

    if ($num_registros_recado > 0) { 
        echo "<script>
                window.open('lista_recados.php','envio','scrollbars=yes,width=810,height=250');
                </script>";
    } else {
        //echo "caso contr�rio.";
    }
?>

<!DOCTYPE html>
<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        
        <link rel="stylesheet" type="text/css" href="./css/style.css"> 
        <link rel="stylesheet" type="text/css" href="./css/normalize.css"> 
        <link rel="stylesheet" type="text/css" href="./css/print.css" media="print" > 
        <title><?php echo $Title ?></title>
        <base target="conte�do">
    </head>

    <body topmargin="0" bgcolor="#FFDAB9"<?php echo $cor_pagina ?>>
        <table class="responstable" style="border:none;background:none">
          <tr style="border:none;background-color: rgba(234, 243, 243, 0);">
            <td height="48" style="border:none">
                
            <!-- <img style="margin: -19px 0px 0px 0px;" border="0" src="img/h2b.png" width="450" height="70">-->
            </td>
          </tr>
        </table>
    </body>
</html>