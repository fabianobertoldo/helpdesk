<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Verifica��o de Chamado</title>
</head>

<body topmargin="0" bgcolor="#FFDAB9"<?php echo $cor_pagina ?>">>

<form method="POST" action="verifica_chamado.php">
    <center>
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="250">
      <tr>
        <td>
        <p align="center"><font face="Arial">Verifica��o de Chamado</font></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>
        <p align="center"><font face="Arial" size="2">N�mero do Chamado</font></td>
      </tr>
      <tr>
        <td>
        <p align="center"><input type="text" name="numero" size="20"></td>
      </tr>
      <tr>
        <td>
        <p align="center"><font face="Arial" size="2">Nome</font></td>
      </tr>
      <tr>
        <td>
        <p align="center"><input name="nome" size="20"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>
        <p align="center"><input type="submit" value="Ver Status" name="B1"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table>
    </center>
  </div>
  <p align="center">&nbsp;</p>
  <p align="center">&nbsp;</p>
</form>
<p align="center">&nbsp;</p>

</body>

</html>
