<?php
     include "config.php";
     include "valida_user.inc";
     include "layout.php";

    mysql_connect($Host, $Usuario, $Senha);
    mysql_select_db($Base);

    $sQuery = " select cod_usuario, nom_usuario, login, nivel
                from   usuarios
                order by login";
    $oUsers = mysql_query($sQuery);
    $num_registros = mysql_num_rows($oUsers);

?>


<html>

<head>

<link rel="stylesheet" type="text/css" href="./css/style.css"> 
<link rel="stylesheet" type="text/css" href="./css/normalize.css"> 
<link rel="stylesheet" type="text/css" href="./css/print.css" media="print"> 
<title><?php echo $Title ?></title>
</head>

<body bgcolor="#FFDAB9"<?php echo $cor_pagina ?>" onload="document.form1.recado.focus()">
<form name="form1" method="POST" action="save_recado.php">
<div align="center">
    <center>
    <table border="0" cellspacing="1" cellpadding="1" align="center" style="BORDER-RADIUS: 10px; padding: 10px; border-color: #167f92; border-style: solid; border-width:1; font-family: verdana; font-size:10;">
      <tr>
        <td width="447" height="30" colspan="2" bgcolor="<?php echo $cor_bg_tit_campos ?>"><Font face="Arial" size="2" color="<?php echo $cor_titulos_form ?>"><p align="center"><b><?php echo $tit_novo_recado ?></b></p></font>
        </td>
      </tr>
      <tr>
      <td bgcolor="<?php echo $cor_bg_tit_campos ?>"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>"><b>Recado:</b></font></td>
      </tr>
      <tr>
      <td bgcolor="<?php echo $cor_bg_dados_inputs ?>"><textarea rows="8" name="recado" cols="50"></textarea></td>
      </tr>
      <tr>
      <td bgcolor="<?php echo $cor_bg_tit_campos ?>"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>"><b>Para:</b></font></td>
      </tr>
      <tr>
      <td bgcolor="<?php echo $cor_bg_dados_inputs ?>">
      <select size="1" name="user_from">
      <?php
      while ($oRow = mysql_fetch_object($oUsers)){
            echo "<option value=\"$oRow->login\">$oRow->login</option>";
      }


      ?>
<?php
      echo $num_registros;
?>
      
      </select>
      </td>
      </tr>
      <tr>
        <td width="394" colspan="2" height="30" bgcolor="<?php echo $cor_bg_tit_campos ?>">
        <p align="right"><input STYLE="background: #167F92;
    border: none;
    color: white;
    font-size: 12px;
    padding: 4px;
    border-radius: 2px;"type="submit" value="ADICIONAR RECADO" name="B1">&nbsp;
        <input STYLE="background: #167F92;
    border: none;
    color: white;
    font-size: 12px;
    padding: 4px;
    border-radius: 2px;"type="reset" value="LIMPAR" name="B2"></td>
      </tr>
    </table>
    </center>
  </div>
</form>

</body>

</html>
