<?php
    ini_set('default_charset','UTF-8');
    date_default_timezone_set("America/Fortaleza");
    include "config.php";
    include "valida_user.inc";
    include "layout.php";

    mysql_connect($Host, $Usuario, $Senha);
    mysql_select_db($Base);
    
    $sQuery = " select cod_usuario, nom_usuario, login, nivel
                from   usuarios
                order by nom_usuario";
    $oUsers = mysql_query($sQuery);
    $num_registros = mysql_num_rows($oUsers);
?>


<html>
    <head>
        <link rel="stylesheet" type="text/css" href="./css/style.css"> 
        <link rel="stylesheet" type="text/css" href="./css/normalize.css"> 
        <link rel="stylesheet" type="text/css" href="./css/print.css" media="print"> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
        <TITLE><?php echo $Title ?></TITLE>
    </head>
    <body style="font-family: verdana; font-size:11;" bgcolor="#FFDAB9">
    
    
        <table id="table_id" class="display">
            <thead>
                <tr>
                    <th></th>
                    <th>Codigo</th>
                    <th>Nome</th>
                    <th>Login</th>
                    <th>Nível de Acesso</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($oRow = mysql_fetch_object($oUsers)) {
                    echo "<tr>
                              <td align=\"center\"><a href=\"#\" onClick=\"excluir('". $oRow->cod_usuario . "')\">
                              <img src=\"img/excluir.jpg\" alt=\"Excluir\" width=\"15\" height=\"16\" border=\"0\"></a></td>
                              <td><center><font color=\"$cor_dados\">$oRow->cod_usuario</font></center></td>
                              <td><center><font color=\"$cor_dados\">$oRow->nom_usuario</font></center></td>
                              <td><center><font color=\"$cor_dados\">$oRow->login</font></center></td>
                              <td><center><font color=\"$cor_dados\">$oRow->nivel</font></center></td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
        
        
        <table width="450" border="0" align="center">
        <center><font face="verdana" size="1" color="<?php echo $cor_outros_textos ?>">*Por motivo de segurança não será possível alterar dados dos usuarios cadastrados.
        Para alterar, exclua o existente e cadastre novamente.</font></center>
        </td></tr>
        <tr><td>
        </table>
    
    </body>
    <script>
        function excluir(id){
            if (confirm('Confirmar Exclusão?')){
                window.location = 'delete_user.php?id='+id
        	}
        }
        $(document).ready( function () {
            $('#table_id').DataTable();
        } );
    
    </script>
</html>
