<?php

    include "config.php";
    include "valida_user.inc";
     include "layout.php";

    $mysqli = new mysqli($Host,  $Usuario, $Senha, $Base);
    
    $sQuery = " delete from chamados
                where  codigo = " . $_GET["id"];
    if ($mysqli->query($sQuery)) {
       echo "<script>window.location='listar_chamado.php'</script>";
    } else {
        echo "Problemas excluindo Chamado\n";
    }

?>
