<?php
    ini_set('default_charset','UTF-8');
    date_default_timezone_set("America/Fortaleza");
    $date = date("y/m/d");
    $hora = date("H:i");
    
    include "config.php";
    include "layout.php";
    include "dao.php";
    $sQuery1 = "insert into chamados (data_abertura, data_fecha, hora_abertura, hora_fecha, setor, ip, descricao, solucao, tipo, nome, email, status, obs)
             values ('" . $date . "',
                     '" . "" . "',
                     '" . $hora . "',
                     '" . "" . "',
                     '" . $_POST["setor"]  . "',
                     '" . $_POST["ip"] . "',
                     '" . $_POST["descricao"]  . "',
                     '" . "" . "',
                     '" . $_POST["tipo"]  . "',
                     '" . $_POST["nome"]  . "',
                     '" . $_POST["email"]  . "',
                     '" . "Aberto"  . "',
                     '" . ""  . "')";

   $mysqli->query($sQuery1);
    
    // Chame o arquivo com as Classes do PHPMailer
    require_once('phpmailer/class.phpmailer.php');
    
    // Instância a classe PHPMailer
    $mail = new PHPMailer();
    
    // Configuração dos dados do servidor e tipo de conexão (Estes dados você obtem com seu host)
    $mail->IsSMTP(); // Define que a mensagem será SMTP
    $mail->Host = "oticagospel.com.br"; // Endereço do servidor SMTP
    $mail->SMTPAuth = true; // Autenticação (True: Se o email será autenticado ou False: se o Email não será autenticado)
    $mail->Username = 'gospel'; // Usuário do servidor SMTP
    $mail->Password = 'Ti@Em@il'; // A Senha do email indicado acima
    
    // Remetente (Identificação que será mostrada para quem receber o email)
    $mail->From = "suporte@oticagospel.com.br";
    $mail->FromName = "Suporte de T.I - GRUPO GOSPEL";
    
    // Destinatário
    $mail->AddAddress($_POST["email"], $_POST["nome"]);
    
    
    // Opcional (Se quiser enviar cópia do email)
    $mail->AddBCC('hailton@oticagospel.com.br', 'Copia Oculta');
    $mail->AddBCC('fabiano@oticagospel.com.br', 'Copia Oculta');
    
    // Define tipo de Mensagem que vai ser enviado
    $mail->IsHTML(true); // Define que o e-mail será enviado como HTML
   
    // Assunto e Mensagem do email
    $id = selectIdPorDataHoraUser($date, $hora,$_POST["nome"]);
    $assunto = "Atendimento HELPDESK - ID:" . $id;
    $mail->Subject = $assunto; // Assunto da mensagem
    $mail->Body = '<!DOCTYPE html>
                    <html>
                    <head>
                        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                    	<title></title>
                    </head>
                    	<body>
                    		<table style="margin: 1em 0; width: 50%; overflow: hidden; background: #FFF; color: #024457;  border-radius: 10px; border: 1px solid #167F92;">	  
                    			<tbody>
                    			  	<tr style="background-color: #167F92;">    
                    			    	<th width="30"><font style="COLOR: #f2f2f2;" size="1" face="verdana" color="#000000">
                    				    	<center>CODIGO</center></font>
                    			    	</th>
                    
                    				    <th width="70"><font style="
                    						    COLOR: #f2f2f2;
                    						" size="1" face="verdana" color="#000000"><center>DT. ABERT.</center></font>
                    					</th>
                    				    <th width="70"><font style="
                    						    COLOR: #f2f2f2;
                    						" size="1" face="verdana" color=" #000000"><center>HR ABERTURA.</center></font>
                    					</th>
                    				    <th width="150"><font style="
                    						    COLOR: #f2f2f2;
                    						" size="1" face="verdana" color=" #000000"><center>SETOR</center></font>
                    				    </th>
                    				    <th width="50%"><font style="
                    						    COLOR: #f2f2f2;
                    						" size="1" face="verdana" color=" #000000"><center>DESC. PROBLEMA</center></font>
                    					</th>
                    					
                    				    <th width="50"><font style="
                    						    COLOR: #f2f2f2;
                    						" size="1" face="verdana" color=" #000000"><center>TIPO</center></font>
                    					</th>
                    				    <th width="160"><font style="
                    						    COLOR: #f2f2f2;
                    						" size="1" face="verdana" color=" #000000"><center>NOME</center></font>
                    					</th>
                    				    <th width="100"><font style="
                    						    COLOR: #f2f2f2;
                    						" size="1" face="verdana" color=" #000000"><center>STATUS</center></font>
                    					</th>
                    			    </tr>	
                    			  
                    			    <tr style="background-color: aliceblue;">                  
                    			      	<td><center><a href="#" style="text-decoration: none"><font color="#000000">' . $id . '</font></a></center></td>
                    			      	<td><center><a href="#" style="text-decoration: none"><font color="#000000">' . $date . '</font></a></center></td>
                    			     	<td><center><a href="#" style="text-decoration: none"><font color="#000000">' . $hora . '</font></a></center></td>
                    			      	<td><center><a href="#" style="text-decoration: none"><font color="#000000">' . $_POST["setor"]  . '</font></a></center></td>
                    			      	<td><center><a href="#" style="text-decoration: none"><font color="#000000">' . $_POST["descricao"]  .'</font></a></center></td>
                    			      	<td><center><a href="#" style="text-decoration: none"><font color="#000000">' . $_POST["tipo"]  . '</font></a></center></td>
                    			      	<td><center><a href="#" style="text-decoration: none"><font color="#000000">' . $_POST["nome"]  . '</font></a></center></td>
                    			      	<td><center><a href="#" style="text-decoration: none"><font color="#000000">Aberto</font></a></center></td>
                    			    </tr>  
                    			</tbody>
                    		</table>
                    		<h1 style="font-size: 15px;">*ACOMPANHE O ANDAMENTO DO SEU CHAMADO NA PAGINA DO HELPDESK</h1>
                    	</body>
                    </html>
                    
                    ';
    
    // Envia a Mensagem
    $enviado = $mail->Send();
    
    // Verifica se o email foi enviado
    if($enviado)    {
        
        $link = preg_replace(array("/(á|à|ã|â|ä)/","/(Á|À|Ã|Â|Ä)/","/(é|è|ê|ë)/","/(É|È|Ê|Ë)/","/(í|ì|î|ï)/","/(Í|Ì|Î|Ï)/",
        "/(ó|ò|õ|ô|ö)/","/(Ó|Ò|Õ|Ô|Ö)/","/(ú|ù|û|ü)/","/(Ú|Ù|Û|Ü)/","/(ñ)/","/(Ñ)/"),
        explode(" ","a A e E i I o O u U n N"),$_POST['setor']);
        
        echo "<script type='text/javascript'>
        window.location.href = 'listar_chamado_user_" .$link. ".php';
     </script>";
    }
    else    {
         echo "<script type='text/javascript'>
            alert ('Não foi possível enviar o e-mail, devido ao erro de: '.$mail->ErrorInfo);
          </script>";
    }
    


?>


      

