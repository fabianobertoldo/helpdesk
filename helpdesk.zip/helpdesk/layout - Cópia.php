
<?

    mysql_connect($Host, $Usuario, $Senha);
    mysql_select_db($Base);


    $sQuery_cor = "select codigo, cor_pagina, cor_titulos_form, cor_titulos_campos, cor_dados, cor_pass_grade, cor_bg_tit_campos, cor_bg_dados_inputs, cor_outros_textos, cor_bg_menu, cor_itens_menu
                from   layout
                where codigo like '1'
                order by codigo";
    $oUsers_cor = mysql_query($sQuery_cor);
    $num_registros_cor = mysql_num_rows($oUsers_cor);

$oRow_cor = mysql_fetch_object($oUsers_cor);


$cor_pagina = $oRow_cor->cor_pagina;
$cor_titulos_form = $oRow_cor->cor_titulos_form;
$cor_titulos_campos = $oRow_cor->cor_titulos_campos;
$cor_dados = $oRow_cor->cor_dados;
$cor_pass_grade = $oRow_cor->cor_pass_grade;
$cor_bg_tit_campos = $oRow_cor->cor_bg_tit_campos;
$cor_bg_dados_inputs = $oRow_cor->cor_bg_dados_inputs;
$cor_outros_textos = $oRow_cor->cor_outros_textos;
$cor_bg_menu = $oRow_cor->cor_bg_menu;
$cor_itens_menu = $oRow_cor->cor_itens_menu;

?>

<?php

    mysql_connect($Host, $Usuario, $Senha);
    mysql_select_db($Base);


    $sQuery_texto = "select codigo, email, title_confirmacao, Title, tit_novo_chamado, tit_atu_chamado, tit1_list_chamado, tit_vis_chamado, tit_rela_chamados, tit_novo_user, tit_novo_recado, tit_lista_recado, filtro_inicial
                from   layout
                order by codigo";
    $oUsers_texto = mysql_query($sQuery_texto);
    $num_registros_texto = mysql_num_rows($oUsers_texto);

$oRow_texto = mysql_fetch_object($oUsers_texto);

$email = $oRow_texto->email;
$title_confirmacao = $oRow_texto->title_confirmacao;
$Title = $oRow_texto->Title;
$tit_novo_chamado = $oRow_texto->tit_novo_chamado;
$tit_atu_chamado = $oRow_texto->tit_atu_chamado;
$tit1_list_chamado = $oRow_texto->tit1_list_chamado;
$tit_vis_chamado = $oRow_texto->tit_vis_chamado;
$tit_rela_chamados = $oRow_texto->tit_rela_chamados;
$tit_novo_user = $oRow_texto->tit_novo_user;
$tit_novo_recado = $oRow_texto->tit_novo_recado;
$tit_lista_recado = $oRow_texto->tit_lista_recado;
$filtro_inicial = $oRow_texto->filtro_inicial;


?>


