<?php
     include "valida_user.inc";
     include "config.php";
     include "layout.php";
?>

<HTML>
<HEAD>
 <TITLE><?php echo $Title ?></TITLE>
</HEAD>
<BODY bgcolor="<?php echo $cor_pagina ?>">


<table width="600" align="center" border="0">
<tr>
<td><center><img src="img/h2b.png"></center></td>
</tr>
<tr>
<td><center><font face="verdana" size="2" color="<?php echo $cor_outros_textos ?>"><b>Logout do Sistema</b></font></center></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td><font face="verdana" size="2" color="<?php echo $cor_outros_textos ?>"><center>Prezado(a) <?php echo $nome_usuario ?>, o logout foi realizado com sucesso. <a href="index.php">Clique aqui<a>, para realizar o Login novamente.</center></font></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td><font face="verdana" size="2" color="<?php echo $cor_outros_textos ?>"><center><b></b></center></font></td>
</tr>
</table>

<?php

//      @session_write_close();
    @session_start(); // Inicializa a sess�o

    $_SESSION["log_usuario"] = "";
    $_SESSION["pwd_usuario"] = "";


?>
</BODY>
</HTML>
