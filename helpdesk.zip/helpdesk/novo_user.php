<?php
     include "config.php";
     include "valida_user.inc";
     include "layout.php";
?>


<html>
    <head>
        <link rel="stylesheet" type="text/css" href="./css/style.css"> 
        <link rel="stylesheet" type="text/css" href="./css/normalize.css"> 
        <link rel="stylesheet" type="text/css" href="./css/print.css" media="print">
        <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <title><?php echo $Title ?></title>
    </head>

    <body onload="document.form1.nom_usuario.focus()">
        
        <div style="margin-top: -46px;" class="container">    
           <div id="loginbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
                <div class="panel panel-info" >
                    <div class="panel-heading">
                        <div class="panel-title">CADASTRO DE USUÁRIO</div>
                    </div>     
                    <div style="padding-top:30px" class="panel-body" >
                        <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12">
                    </div>
                        
                    <form name="form1" method="post" action="save_user.php">
                        <div style="margin-bottom: 25px" class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                            <input required="yes" id="nome-user" type="text" class="form-control" name="nom_usuario" placeholder="Informe seu nome">                                        
                        </div>
                        
                        <div style="margin-bottom: 25px" class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                            <input required="yes" id="login-user" type="text" class="form-control" name="login" placeholder="Informe um nome de login">                                        
                        </div>
                        
                        <div style="margin-bottom: 25px" class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                            <input required="yes" id="password-username" type="password" class="form-control" name="pwd_usuario" placeholder="Informe uma senha">                                        
                        </div>
                        
                        <div style="margin-bottom: 25px" class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                            <select required="yes" class="form-control" size="1" name="nivel">     
                                <option value="adm">ADM</option>
                            </select>
                        </div>
                        
                        <div style="margin-top:10px" class="form-group">
                            <!-- Button -->
                            <div class="col-sm-12 controls">
                            <input class="btn btn-success" type = "submit" name="Submit" value ="CADASTRAR">
                        </div>
                    </form>
                </div>
            </div>
        </div>
</body>

</html>
