<?php
    include "config.php";
    include "valida_user.inc";
?>

<?php
         $mysqli = new mysqli($Host,  $Usuario, $Senha, $Base);
        $sQuery = "select codigo, cor_pagina, cor_titulos_form, cor_titulos_campos, cor_dados, cor_pass_grade, cor_bg_tit_campos, cor_bg_dados_inputs, cor_outros_textos, cor_bg_menu, cor_itens_menu
                    from   layout
                    where  codigo like 1
                    order by codigo";
        $oUsers = $mysqli->query($sQuery);
        $oRow = $oUsers->fetch_object();
        
//acima select dos itens de configura��es do layout - abaixo select das cores para o objeto select do form..


?>


<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<link rel="stylesheet" type="text/css" href="./css/style.css"> 
<link rel="stylesheet" type="text/css" href="./css/normalize.css"> 
<link rel="stylesheet" type="text/css" href="./css/print.css" media="print"> 
<title><?php echo $Title ?></title>
</head>

<body>

<form method="POST" action="save_cores_textos.php?op=cores">
    <center>
    <table border="0" cellpadding="0" cellspacing="0" style="font-size:12px; border-collapse: collapse" bordercolor="#111111" width="650">
      <tr>
      <td colspan="4" width="650" height="19" bgcolor="black"><Font face="Arial" size="2" color="white"><p align="center"><b>Configura��o de Cores do Sistema.</b></td>
      </tr>
      <tr>
      <td colspan="4" width="650" height="19"></td>
      </tr>
      <tr>
        <td width="440" height="22">
        <b><font face="Verdana" size="1">
        Cor do fundo das p�ginas (BackGround).</font></b></td>
        <td width="80" height="22">
        <p align="center">
        <select size="1" name="D1">
        <option style="background-color: <?php echo $oRow->cor_pagina ?>" value="<?php echo $oRow->cor_pagina ?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
        <?php include "select_cores.php" ?>
        </select>
        </select></td>
        <td width="70" height="22">
        <p align="center"><input type="text" name="T1" size="7" value="<?php echo $oRow->cor_pagina ?>"></td>
        <td style="background-color: <?php echo $oRow->cor_pagina ?>" width="60" height="22">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="4" width="650" height="19"><hr size="1" align="left" color="black" width="650"></td>
      </tr>
      
      <tr>
        <td width="440" height="22">
        <b><font face="Verdana" size="1">
        Cor dos T�tulos dos Formul�rios.</font></b></td>
        <td width="80" height="22">
        <p align="center">
        <select size="1" name="D2">
        <option style="background-color: <?php echo $oRow->cor_titulos_form ?>" value="<?php echo $oRow->cor_titulos_form ?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
        <?php include "select_cores.php" ?>
        </select>
        </select></td>
        <td width="70" height="22">
        <p align="center"><input type="text" name="T2" size="7" value="<?php echo $oRow->cor_titulos_form ?>"></td>
        <td style="background-color: <?php echo $oRow->cor_titulos_form ?>" width="60" height="22">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="4" width="650" height="19"><hr size="1" align="left" color="black" width="650"></td>
      </tr>
      
      <tr>
        <td width="440" height="22">
        <b><font face="Verdana" size="1">
        Cor dos T�tulos dos Campos dos Formul�rio.</font></b></td>
        <td width="80" height="22">
        <p align="center">
        <select size="1" name="D3">
        <option style="background-color: <?php echo $oRow->cor_titulos_campos ?>" value="<?php echo $oRow->cor_titulos_campos ?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
        <?php include "select_cores.php" ?>
        </select>
        </select></td>
        <td width="70" height="22">
        <p align="center"><input type="text" name="T3" size="7" value="<?php echo $oRow->cor_titulos_campos ?>"></td>
        <td style="background-color: <?php echo $oRow->cor_titulos_campos ?>" width="60" height="22">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="4" width="650" height="19"><hr size="1" align="left" color="black" width="650"></td>
      </tr>
      
      <tr>
        <td width="440" height="22">
        <b><font face="Verdana" size="1">
        Cor dos Dados Exibidos (Listas).</font></b></td>
        <td width="80" height="22">
        <p align="center">
        <select size="1" name="D4">
        <option style="background-color: <?php echo $oRow->cor_dados ?>" value="<?php echo $oRow->cor_dados ?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
        <?php include "select_cores.php" ?>
        </select>
        </select></td>
        <td width="70" height="22">
        <p align="center"><input type="text" name="T4" size="7" value="<?php echo $oRow->cor_dados ?>"></td>
        <td style="background-color: <?php echo $oRow->cor_dados ?>" width="60" height="22">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="4" width="650" height="19"><hr size="1" align="left" color="black" width="650"></td>
      </tr>

      <tr>
        <td width="440" height="22">
        <b><font face="Verdana" size="1">
        Cor da linha quando o mouse estiver sobre.</font></b></td>
        <td width="80" height="22">
        <p align="center">
        <select size="1" name="D5">
        <option style="background-color: <?php echo $oRow->cor_pass_grade ?>" value="<?php echo $oRow->cor_pass_grade ?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
        <?php include "select_cores.php" ?>
        </select>
        </select></td>
        <td width="70" height="22">
        <p align="center"><input type="text" name="T5" size="7" value="<?php echo $oRow->cor_pass_grade ?>"></td>
        <td style="background-color: <?php echo $oRow->cor_pass_grade ?>" width="60" height="22">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="4" width="650" height="19"><hr size="1" align="left" color="black" width="650"></td>
      </tr>
      
      <tr>
        <td width="440" height="22">
        <b><font face="Verdana" size="1">
        Cor de Fundo das Linhas dos T�tulos e dos Campos dos Formul�rio (BackGround).</font></b></td>
        <td width="80" height="22">
        <p align="center">
        <select size="1" name="D6">
        <option style="background-color: <?php echo $oRow->cor_bg_tit_campos ?>" value="<?php echo $oRow->cor_bg_tit_campos ?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
        <?php include "select_cores.php" ?>
        </select>
        </select></td>
        <td width="70" height="22">
        <p align="center"><input type="text" name="T6" size="7" value="<?php echo $oRow->cor_bg_tit_campos ?>"></td>
        <td style="background-color: <?php echo $oRow->cor_bg_tit_campos ?>" width="60" height="22">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="4" width="650" height="19"><hr size="1" align="left" color="black" width="650"></td>
      </tr>
      
      <tr>
        <td width="440" height="22">
        <b><font face="Verdana" size="1">
        Cor de Fundo dos Dados e dos Elementos do Formul�rio.</font></b></td>
        <td width="80" height="22">
        <p align="center">
        <select size="1" name="D7">
        <option style="background-color: <?php echo $oRow->cor_bg_dados_inputs ?>" value="<?php echo $oRow->cor_bg_dados_inputs ?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
        <?php include "select_cores.php" ?>
        </select>
        </select></td>
        <td width="70" height="22">
        <p align="center"><input type="text" name="T7" size="7" value="<?php echo $oRow->cor_bg_dados_inputs ?>"></td>
        <td style="background-color: <?php echo $oRow->cor_bg_dados_inputs ?>" width="60" height="22">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="4" width="650" height="19"><hr size="1" align="left" color="black" width="650"></td>
      </tr>
      
      <tr>
        <td width="440" height="22">
        <b><font face="Verdana" size="1">
        Cor dos Textos Diversos.</font></b></td>
        <td width="80" height="22">
        <p align="center">
        <select size="1" name="D8">
        <option style="background-color: <?php echo $oRow->cor_outros_textos ?>" value="<?php echo $oRow->cor_outros_textos ?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
        <?php include "select_cores.php" ?>
        </select>
        </select></td>
        <td width="70" height="22">
        <p align="center"><input type="text" name="T8" size="7" value="<?php echo $oRow->cor_outros_textos ?>"></td>
        <td style="background-color: <?php echo $oRow->cor_outros_textos ?>" width="60" height="22">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="4" width="650" height="19"><hr size="1" align="left" color="black" width="650"></td>
      </tr>

      <tr>
        <td width="440" height="22">
        <b><font face="Verdana" size="1">
        Cor de Fundo dos Itens do Menu (BackGround).</font></b></td>
        <td width="80" height="22">
        <p align="center">
        <select size="1" name="D9">
        <option style="background-color: <?php echo $oRow->cor_bg_menu ?>" value="<?php echo $oRow->cor_bg_menu ?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
        <?php include "select_cores.php" ?>
        </select>
        </select></td>
        <td width="70" height="22">
        <p align="center"><input type="text" name="T9" size="7" value="<?php echo $oRow->cor_bg_menu ?>"></td>
        <td style="background-color: <?php echo $oRow->cor_bg_menu ?>" width="60" height="22">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="4" width="650" height="19"><hr size="1" align="left" color="black" width="650"></td>
      </tr>

      <tr>
        <td width="440" height="22">
        <b><font face="Verdana" size="1">
        Cor dos Itens do Menu.</font></b></td>
        <td width="80" height="22">
        <p align="center">
        <select size="1" name="D10">
        <option style="background-color: <?php echo $oRow->cor_itens_menu ?>" value="<?php echo $oRow->cor_itens_menu ?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
        <?php include "select_cores.php" ?>
        </select>
        </select></td>
        <td width="70" height="22">
        <p align="center"><input type="text" name="T10" size="7" value="<?php echo $oRow->cor_itens_menu ?>"></td>
        <td style="background-color: <?php echo $oRow->cor_itens_menu ?>" width="60" height="22">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="4" width="650" height="19"><hr size="1" align="left" color="black" width="650"></td>
      </tr>
      <tr>
      <td colspan="4" width="650" height="19" bgcolor="black"><Font face="Arial" size="1" color="white"><b>Altere as cores conforme os itens acima e clique em gravar configura��es.</b></td>
      </tr>
      </table>
    </center>
  </div>
  <p align="center"><input style="background: #167F92;
    border: none;
    color: white;
    font-size: 12px;
    padding: 4px;
    border-radius: 2px;" type="submit" value="GRAVAR CONFIGURA��ES" name="B1"></p>
</form>
<center>
<table width="650">
<tr><td><center><?php include "bnt_layout.php" ?></center></td></tr>
</table>
</center>
</body>
</html>
