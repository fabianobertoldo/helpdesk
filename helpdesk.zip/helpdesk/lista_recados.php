<?php

    include "config.php";
    include "valida_user.inc";
    include "script_grade.php";
     include "layout.php";
    
    
    mysql_connect($Host, $Usuario, $Senha);
    mysql_select_db($Base);
    
    $sQuery = " select codigo, data, hora, user_abriu, user_from, recado, concluido
                from   recados
                where concluido like 'n%' and user_from like '$nome_usuario%'
                order by codigo desc";
    $oUsers = mysql_query($sQuery);
    $num_registros = mysql_num_rows($oUsers);
?>
    
<script>
    function alterar(id){
        window.location = 'fecha_recado.php?id='+id;
    }
</script>



<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><title>Recados para o usu�rio <?php echo $nome_usuario ?>.</title></head>
<body bgcolor="#FFDAB9"<?php echo $cor_pagina ?>">
<table width="770" border="0" align="center" style="border-color: black; border-style: solid; border-width:1; font-family: verdana; font-size:10;">
        <tr>
        <td bgcolor="<?php echo $cor_bg_tit_campos ?>" colspan="11"><Font face="Arial" size="2" color="<?php echo $cor_titulos_form ?>"><p align="center"><b><?php echo $tit_lista_recado ?> para o usu�rio <?php echo $nome_usuario ?>.</b></p></font></td>
        </tr>
        <tr bgcolor="<?php echo $cor_bg_tit_campos ?>">
            <td>&nbsp;</td>
            <td width="30"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>"><center>Codigo</center></font></td>
            <td width="70"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>"><center>Data</center></font></td>
            <td width="70"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>"><center>Hora</center></font></td>
            <td width="150"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>"><center>De</center></font></td>
            <td width="150"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>"><center>Para</center></font></td>
            <td width="300"><font size="1" face="verdana" color="<?php echo $cor_titulos_campos ?>"><center>Recado</center></font></td>
        </tr>
        <?php
        while ($oRow = mysql_fetch_object($oUsers)) {
            echo "<tr bgcolor=\"$cor_bg_dados_inputs\" ONMOUSEOVER=\"move_i(this)\" ONMOUSEOUT=\"move_o(this)\">
                      <td align=\"center\"><a href=\"#\" onClick=\"alterar('". $oRow->codigo . "')\"><img src=\"img/excluir.jpg\" alt=\"Excluir\" width=\"15\" height=\"16\" border=\"0\"></a></td>
                      <td><center><font color=\"$cor_dados\">$oRow->codigo</font></center></td>
                      <td><center><font color=\"$cor_dados\">$oRow->data</font></center></td>
                      <td><center><font color=\"$cor_dados\">$oRow->hora</font></center></td>
                      <td><center><font color=\"$cor_dados\">$oRow->user_abriu</font></center></td>
                      <td><center><font color=\"$cor_dados\">$oRow->user_from</font></center></td>
                      <td><center><font color=\"$cor_dados\">$oRow->recado</font></center></td>
                  </tr>";
        }
        ?>
</table >

</body>
</html>
