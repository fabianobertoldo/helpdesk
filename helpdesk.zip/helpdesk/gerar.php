﻿<?php
$nome_arquivo = $_POST['arquivo']; // pego nessa variavel o nome que você atribuiu no formulario da pagina index.php para o arquivo a ser gerado .xls - excel
// peguei a variavel datainicio vindo do form e transformei ela pra o formato ingles do SQL Y-m-d
//a variavel de saida final da data em formato SQL é a $datavencinicio
$datainicio = $_POST['datainicio']; 
$datavencinicio = "$datainicio";
$diavencinicio = substr("$datavencinicio",0,2);
$mesvencinicio = substr("$datavencinicio",3,2);
$anovencinicio = substr("$datavencinicio",6,4);
$datavencinicio = $anovencinicio."-".$mesvencinicio."-".$diavencinicio;

// peguei a variavel datafinal vindo do form e transformei ela pra o formato ingles do SQL Y-m-d
//a variavel de saida final da data em formato SQL é a $datavencfinal
$datafinal = $_POST['datafinal'];
$datavencfinal = "$datafinal";
$diavencfinal = substr("$datavencfinal",0,2);
$mesvencfinal = substr("$datavencfinal",3,2);
$anovencfinal = substr("$datavencfinal",6,4);
$datavencfinal = $anovencfinal."-".$mesvencfinal."-".$diavencfinal;

//Incluir a classe excelwriter
include("excelwriter.inc.php");

//Você pode colocar aqui o nome do arquivo que você deseja salvar.
$excel=new ExcelWriter("".$nome_arquivo."");

if ($excel==false) {
    echo $excel->error;
}

//Escreve o nome dos campos de uma tabela. Esses vão ser o texto do titulo das colunas no arquivo gerado
$myArr = array('id','data_abertura','data_fecha', 'hora_abertura', 'hora_fecha','setor','descricao', 'solucao','nome','email','status','obs');
$excel->writeLine($myArr);

//Seleciona os campos de uma tabela
$conn = mysql_connect("localhost", "gospel_user", "grifo1986") or die ('Não foi possivel conectar ao banco de dados! Erro: ' . mysql_error());
if ($conn) {
    mysql_select_db("gospel_helpdesk", $conn);
}
$consulta = "select * from chamados where data BETWEEN '$datavencinicio' AND '$datavencfinal' order by id";
$resultado = mysql_query($consulta);
if ($resultado == true) {
    while($linha = mysql_fetch_array($resultado)){
        $myArr = array($linha['id'],$linha['data_abertura'],$linha['data_fecha'],$linha['hora_abertura'],$linha['hora_fecha'],$linha['setor'],$linha['descricao'],$linha['solucao'],$linha['nome'],$linha['email'],$linha['status'],$linha['obs']); //campos da tabela dados
        $excel->writeLine($myArr);
    }
}

$excel->close();
echo "O relatório foi gerado com sucesso com dados<br>cadastrados de ".$datainicio." até ".$datafinal.".<br>
<a href=\"".$nome_arquivo."\">Clique aqui para fazer o download do arquivo</a>";
?>