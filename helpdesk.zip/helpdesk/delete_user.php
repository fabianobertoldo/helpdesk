<?php

    include "config.php";
    include "valida_user.inc";
    include "layout.php";

    mysql_connect($Host, $Usuario, $Senha);
    mysql_select_db($Base);
    
    $sQuery = " delete from usuarios
                where  cod_usuario = " . $_GET["id"];
    if (mysql_query($sQuery)) {
       echo "<script>window.location='listar_user.php'</script>";
    } else {
        echo "Problemas excluindo usuáio\n";
    }

?>
