<?php
    include "config.php";
    include "layout.php";
?>

<HTML>
<HEAD>
 <TITLE><?php echo $Title ?></TITLE>

<script LANGUAGE="JavaScript">
function validation() {
    if (document.form1.nome.value.length < 1) {
	    window.alert("Favor Preencher o campo NOME!");
	    document.form1.nome.focus();
		return false;
	}
	if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(form1.email.value)))
    {
        window.alert("Favor Preecher um E-Mail v�lido.");
	    document.form1.email.focus();
        return false;
    }
    if (document.form1.setor.value.length < 1) {
	    window.alert("Favor Preencher o campo SETOR!");
	    document.form1.setor.focus();
		return false;
	}
	if (document.form1.descricao.value.length < 1) {
	    window.alert("Favor Preencher o campo Descri��o!");
	    document.form1.descricao.focus();
		return false;
	}
	return true;
}


</script>
<link rel="stylesheet" type="text/css" href="./css/style.css"> 
<link rel="stylesheet" type="text/css" href="./css/normalize.css"> 
<link rel="stylesheet" type="text/css" href="./css/print.css" media="print" > 
</HEAD>

<BODY onload="document.form1.nome.focus()" bgcolor="#FFDAB9"<?php echo $cor_pagina ?>">
<td><center><img src="img/h2b.png"></center></td></br>
<td><center>
  <h1>FA&Ccedil;A SEU CHAMADO</h1></center></td></p>
<form name="form1" method="post" action="save_chamado_user.php" onSubmit="return validation();">
    <table  border="0" cellspacing="0" cellpadding="0" align="center" style="border-color: black; border-style: solid; border-width:1; font-family: verdana; font-size:10;">
        <tr>
      		<td colspan="2" bgcolor="#024457"><Font face="Arial" size="2" color="<?php echo $cor_titulos_form ?>"><p align="center"><b></b></p></font></td>
		</tr>
        <tr>
            <td width="100" bgcolor="#024457">&nbsp;</td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;</td>
        </tr>
        <tr>
            <td width="100" bgcolor="#024457"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>Nome:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;&nbsp;<input type="text" maxlength="50" name="nome" size="50"></td>
        </tr>
        <tr>
            <td width="100" bgcolor="#024457"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>E-mail:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;&nbsp;<input type="text" maxlength="50" name="email" size="50"></td>
        </tr>
        <tr>
            <td width="100" bgcolor="#024457"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>Setor/Lojas:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;
            <select size="1" name="setor">
            <option value="Backoffice">Backoffice</option>
            <option value="dlo">DLO</option>
            <option value="financeiro">Financeiro</option>
            <option value="jms">JMS</option>
            <option value="tlmk">TMLK</option>
            <option value="POS-VENDA">POS-VENDA</option>
            <option value="Loja01">Loja01</option>
            <option value="Loja02">Loja02</option>
            <option value="Loja03">Loja03</option>
            <option value="Loja04">Loja04</option>
            <option value="Loja05">Loja05</option>
            <option value="Loja06">Loja06</option>
            <option value="Loja07">Loja07</option>
            <option value="Loja08">Loja08</option>
            <option value="Loja09">Loja09</option>
            <option value="Loja10">Loja10</option>
            <option value="Loja11">Loja11</option>
            <option value="Loja12">Loja12</option>
            <option value="Loja13">Loja13</option>
            <option value="Loja14">Loja14</option>
            <option value="Loja15">Loja15</option>
            <option value="Loja16">Loja17</option>
            <option value="Loja18">Loja18</option>
            <option value="Loja19">Loja19</option>
            <option value="Loja20">Loja20</option>
            <option value="Loja21">Loja21</option>
            <option value="Loja22">Loja22</option>
            <option value="Loja23">Loja23</option>
            <option value="Loja24">Loja24</option>
            <option value="Loja25">Loja25</option>
            <option value="Loja26">Loja26</option>
            <option value="Loja27">Loja27</option>
            <option value="Loja28">Loja28</option>
            <option value="Loja29">Loja29</option>
            <option value="Loja30">Loja30</option>
            <option value="Loja31">Loja31</option>
            <option value="Loja32">Loja32</option>
            <option value="Loja33">Loja33</option>
            <option value="Loja34">Loja34</option>
            <option value="Loja35">Loja35</option>
            <option value="Loja36">Loja36</option>
            <option value="Loja37">Loja37</option>
            <option value="Loja38">Loja38</option>
            <option value="Loja39">Loja39</option>
            <option value="Loja40">Loja40</option>
            <option value="Loja41">Loja41</option>
            </select></td>
        </tr>
        <tr>
            <td width="100" bgcolor="#024457"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>Tipo:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;
            <select size="1" name="tipo">
            <option value="Hardware">Hardware</option>
            <option value="Software">Software</option>
            <option value="Duvidas">D�vidas</option>
            <option value="Outros">Outros</option>
            </select></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>Descri��o do Problema:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;&nbsp;<textarea rows="5" cols="42" name="descricao"></textarea></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>"><div align="right"><font color="<?php echo $cor_titulos_campos ?>"><b>Observa��o:&nbsp;</b></font></div></td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;&nbsp;<textarea rows="5" cols="42" maxlength="250" name="obs" size="120"></textarea></td>
        </tr>
        <tr>
            <td width="100" bgcolor="<?php echo $cor_bg_tit_campos ?>">&nbsp;</td>
            <td width="400" bgcolor="<?php echo $cor_bg_dados_inputs ?>">&nbsp;</td>
        </tr>
        <tr>
      		<td colspan="2" bgcolor="<?php echo $cor_bg_tit_campos ?>"><p align="center"><input type = "submit" name="Submit" value ="Enviar"><input type="reset" name="limpar" value="Limpar"></p></td>
		</tr>
    </table>
    
<p align="center"><table width="500" border="0">
<tr>
<td><font face="verdana" size="2" color="<?php echo $cor_outros_textos ?>">Os campos com "*" s�o de preenchimento obrigat�rio.<br>Ao enviar o chamado, o mesmo ser� reportado ao Depto de Tecnologia, e uma c�pia ser� enviado para voc� no e-mail informado acima.</font></td>
</tr>
</table>
</form>
</BODY>
</HTML>
