<?php
    date_default_timezone_set("America/Fortaleza");
    $date = date("d/m/y");
    $hora = date("H:i");
    include "config.php";
    include "valida_user.inc";
    include "layout.php";
  
    $status1 = ($_POST["status"]);


    if ($status1 == 'Fechado') {
      $sQuery = "update chamados set
                         data_abertura = '" . $_POST["data_abertura"] . "',
                         data_fecha = '" . $date . "',
                         hora_abertura = '" . $_POST["hora_abertura"] . "',
                         hora_fecha = '" .$hora ."',
                         setor = '" .$_POST["setor"] ."',
                         ip = '" .$_POST["ip"] ."',
                         descricao = '" .$_POST["descricao"] ."',
                         solucao = '" .$_POST["solucao"] ."',
                         tipo = '" .$_POST["tipo"] ."',
                         nome = '" .$_POST["nome"] ."',
                         email = '" .$_POST["email"] ."',
                         status = '" .$_POST["status"] ."',
                         obs = '" .$_POST["obs"] ."',
                         tecnico = '" .$nome_usuario ."'
                 where codigo = " . $_GET["id"];

                 $mysqli->query($sQuery);
                 echo "<script>window.location='listar_chamado.php'</script>";
        }
     else {
      $sQuery = "update chamados set
                         data_abertura = '" . $_POST["data_abertura"] . "',
                         data_fecha = '" . "" . "',
                         hora_abertura = '" . $_POST["hora_abertura"] . "',
                         hora_fecha = '" . "" ."',
                         setor = '" .$_POST["setor"] ."',
                         ip = '" .$_POST["ip"] ."',
                         descricao = '" .$_POST["descricao"] ."',
                         solucao = '" .$_POST["solucao"] ."',
                         tipo = '" .$_POST["tipo"] ."',
                         nome = '" .$_POST["nome"] ."',
                         email = '" .$_POST["email"] ."',
                         status = '" .$_POST["status"] ."',
                         obs = '" .$_POST["obs"] ."',
                         tecnico = '" .$nome_usuario ."'
                 where codigo = " . $_GET["id"];

                 $mysqli->query($sQuery);
                 echo "<script>window.location='listar_chamado.php'</script>";
    }

?>
