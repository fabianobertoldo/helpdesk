<DIV>


<frameset framespacing="0" border="0" frameborder="0" rows="200,*">
 
  <table></table>
  <frame name="cabeçalho" scrolling="no" noresize target="principal" src="envia_consulta_user.php"> 
  <frame name="principal_2" src="listar_chamado_user_Loja11.php">
  <noframes>
  <body>

  <p>Esta página usa quadros mas seu navegador não aceita quadros.</p>

  

  
  </body>
  </noframes>
</frameset>

</DIV>