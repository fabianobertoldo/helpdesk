<?php

// Sistema de HelpDesk
// Base = MySQL

$Host= "localhost";   //<----aqui vc deve configurar o caminho para o host


// helpdesk online
//$Base= "gospel_helpdesk" ;  //nao mude
//$Usuario= "gospel_user" ;   //<---------aqui vc deve colocar o //usuario do mysql

// helpdesk local
$Base= "gospel_helpdesk" ;  //nao mude
$Usuario= "gospel" ;   //<---------aqui vc deve colocar o usuario do mysql

$Senha= "Ti@Em@il" ;  //<---------aqui vc deve colocar a senha do mysql
$Nivel= "adm";



?>
