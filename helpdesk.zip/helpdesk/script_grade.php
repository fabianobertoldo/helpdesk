<?php
     include "valida_user.inc";
     include "layout.php";
?>

<SCRIPT LANGUAGE="JavaScript">
  function move_i(what) { what.style.background='<?php echo $cor_pass_grade ?>'; }
  function move_o(what) { what.style.background='<?php echo $cor_bg_dados_inputs ?>'; }
</SCRIPT>
