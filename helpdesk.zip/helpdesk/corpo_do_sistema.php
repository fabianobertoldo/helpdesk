<?php
    ini_set('default_charset','UTF-8');
    include "config.php";
    include "valida_user.inc";
    include "layout.php";
?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title><?php echo $Title ?></title>
        <link rel="stylesheet" type="text/css" href="./css/style.css"> 
        <link rel="stylesheet" type="text/css" href="./css/normalize.css"> 
        <link rel="stylesheet" type="text/css" href="./css/print.css" media="print" > 
    </head>

    <body bgcolor="#FFDAB9">
        <p align="center"><img style="   width: 273px;    margin: 65px 0 0 -188px;" src="img/gospel.png"/></p>
    </body>
</html>
