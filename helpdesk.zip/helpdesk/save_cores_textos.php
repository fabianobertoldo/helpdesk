<?php

    include "config.php";
    include "valida_user.inc";

    $mysqli = new mysqli($Host,  $Usuario, $Senha, $Base);


    if ($_GET["op"] == 'cores') {
      $sQuery = "update layout set
                         cor_pagina = '" . $_POST["D1"] . "',
                         cor_titulos_form = '" . $_POST["D2"] . "',
                         cor_titulos_campos = '" . $_POST["D3"] . "',
                         cor_dados = '" . $_POST["D4"] . "',
                         cor_pass_grade = '" .$_POST["D5"] ."',
                         cor_bg_tit_campos = '" .$_POST["D6"] ."',
                         cor_bg_dados_inputs = '" .$_POST["D7"] ."',
                         cor_outros_textos = '" .$_POST["D8"] ."',
                         cor_bg_menu = '" . $_POST["D9"] . "',
                         cor_itens_menu = '" . $_POST["D10"] . "'
                 where codigo = " . 1;

     mysql_query($sQuery);
     echo "<script>window.location='altera_cor.php'</script>";
        }
     else {
      $sQuery = "update layout set
                         email = '" . $_POST["T1"] . "',
                         title_confirmacao = '" . $_POST["T2"] . "',
                         Title = '" . $_POST["T3"] . "',
                         tit_novo_chamado = '" . $_POST["T4"] . "',
                         tit_atu_chamado = '" . $_POST["T5"] . "',
                         tit1_list_chamado = '" . $_POST["T6"] . "',
                         tit_vis_chamado = '" . $_POST["T7"] . "',
                         tit_rela_chamados = '" . $_POST["T8"] . "',
                         tit_novo_user = '" . $_POST["T9"] . "',
                         tit_novo_recado = '" . $_POST["T10"] . "',
                         tit_lista_recado = '" . $_POST["T11"] . "',
                         filtro_inicial = '" . $_POST["T12"] . "'
                 where codigo = " . 1;

                 mysql_query($sQuery);
                 echo "<script>window.location='altera_textos.php'</script>";
    }

?>
