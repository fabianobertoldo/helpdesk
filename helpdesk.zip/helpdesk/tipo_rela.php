<?php
    ini_set('default_charset','UTF-8');
    include "config.php";
    include "valida_user.inc";
    include "layout.php";
?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link rel="stylesheet" type="text/css" href="./css/style.css"> 
        <link rel="stylesheet" type="text/css" href="./css/normalize.css"> 
        <link rel="stylesheet" type="text/css" href="./css/print.css" media="print">
        <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
        <script src="//code.jquery.com/jquery-1.10.2.js"></script>
        <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
        <script>
            jQuery(function() {
                jQuery( ".data" ).datepicker({
                    dateFormat: 'dd/mm/yy',
                    dayNames: ['Domingo','Segunda','Tera','Quarta','Quinta','Sexta','S~´abado'],
                    dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
                    dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
                    monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
                    monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'],
                    nextText: 'Próximo',
                    prevText: 'Anterior'
                });
            });
        </script>
        <title><?php echo $Title ?></title>
        <style>div.ui-datepicker{ font-size:12px;}</style>
        <!-- <link rel="stylesheet" type="text/css" href="./css/style.css"> -->
    </head>

    <body bgcolor="#FFDAB9">
        <div class="rel_chamados">
            <h2>Relatório de Chamados</h2>
            <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="650">
                <tr>
                    <td>
                        <form method="POST" target="_blank" action="rela_chamados.php">
                            <select size="1" name="setor" style="float: left;margin: 16px 14px 0 0px;height: 21px;">
                            <option value=""> Todos os Chamados </option>
                            <option value="Backoffice">Backoffice</option>
                            <option value="TMLK">TMLK</option>
                            <?php 
                    	        $i = 1;
                        		while($i <= 44){ 
                                    if($i <= 9){ 
                            	        echo "<option value='LOJA0".$i."'>Loja 0".$i."</option>";
                                    }else{
                                        echo "<option value='LOJA".$i."'>Loja ".$i."</option>";
                                    }
                                        $i++;
                                }
                            ?>
                            </select>
                                <p style="float: left;">De:  <input required="required"  placeholder=" Data Inicial" style="width: 90px;" name="dataInicial" type="text" class="data"></p>
                                <p style="float: left;margin: 17px 1px 2px 17px;"> Até: <input required="required" placeholder=" Data Final" style="width: 90px;"  name="dataFinal" type="text" class="data"></p>
                                <p style="float: left;margin: 17px 0px 0px 30px;"><input style="background: #167F92; border: none;   color: white;   font-size: 12px;
                                    padding: 4px;    border-radius: 2px;"  type="submit" value="GERAR RELATÓIO" name="B1">
                                </p>
                        </form>
                    </td>
                </tr>
                <tr>
                    <td>
                        <font>No DropDown escolha o tipo de relatório desejado e clique no botão "Gerar Relatório".</font>
                    </td>
                </tr>
            </table>
            </center>
        </div>
    </body>
</html>