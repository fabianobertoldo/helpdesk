<html>

<head>
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Nova pagina 1</title>
</head>

<body>
<center>
<table width="650">
<tr>
<td><center>
<form method="POST" action="altera_cor.php">
<input type="submit" value="         Cores          " name="B1"></p>
</form></center>
</td>
<td><center>
<form method="POST" action="altera_textos.php">
<input type="submit" value="Textos e Filtros" name="B1"></p>
</form></center>
</td>
</tr>
</table>
</center>
</body>

</html>
