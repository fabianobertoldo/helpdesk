<?php

    $date = date("d/m/y");
    $hora = date("H:i");
    include "config.php";
    include "valida_user.inc";
     include "layout.php";
    mysql_connect($Host, $Usuario, $Senha);
    mysql_select_db($Base);


    mysql_select_db($Base);

    $sQuery = "insert into recados (data, hora, user_abriu, user_from, recado, concluido)
                 values ('" . $date . "',
                         '" . $hora . "',
                         '" . $nome_usuario . "',
                         '" . $HTTP_POST_VARS["user_from"] . "',
                         '" . $HTTP_POST_VARS["recado"] . "',
                         '" . "n"  . "')";
                         
        mysql_query($sQuery);


?>
<div align="center">
<table width="600">
<tr><td><?php echo "Recado Adicionado com sucesso. No pr�ximo logon do usu�rio o recado ser� exibido." ?></td></tr>
</table>
</div>

