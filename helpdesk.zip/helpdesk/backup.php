<?php
// Backup do site
date_default_timezone_set("America/Fortaleza");
$dbhost = 'localhost';
$dbuser = 'gospel_user';
$dbpass = 'grifo1986';
$dbname = 'gospel_helpdesk';

// Seu e-mail aqui
$sendto = 'Eu <suporte@oticagospel.com.br>';

// O remetente. Pode ser backup@seusite.com
$sendfrom = 'Backup H2B HELP <h2bhelp@oticagospel.com.br>';

// Assunto do e-mail
$sendsubject = 'Backup do help desk ' . date('d/m/Y');

// Corpo do e-mail
$bodyofemail = 'Backup diário do help desk';

$backupfile = 'Autobackup_' . date("Ymd") . '.sql';
$backupzip = $backupfile . '.tar.gz';
system("mysqldump -h $dbhost -u $dbuser -p$dbpass --lock-tables $dbname > $backupfile");
system("tar -czvf $backupzip $backupfile");

include('Mail.php');
include('Mail/mime.php');

$message = new Mail_mime();
$text = "$bodyofemail";
$message->setTXTBody($text);
$message->AddAttachment($backupzip);
$body = $message->get(array(
    'head_charset' => 'utf-8',
    'text_charset' => 'utf-8',
    'html_charset' => 'utf-8'
));
$extraheaders = array("From"=>"$sendfrom", "Subject"=>"$sendsubject");
$headers = $message->headers($extraheaders);
$mail = Mail::factory("mail");
$mail->send("$sendto", $headers, $body);

//Remover o arquivo do servidor (opcional)
unlink($backupzip);
unlink($backupfile);
?>
</br></br>
<tr>
<td><center><img src="img/h2blogo.png"></center></td>
<td><center><h1>Backup realizado com sucesso!...</h1></center></td>
<td><center><h2><a href="javascript:window.history.go(-1)">Voltar ao Sistema</a></h2></center></td>
</tr>
<tr>

