<?php
     include "config.php";
     include "valida_user.inc";
     include "layout.php";
?>


<html >

<head>
<link rel="stylesheet" type="text/css" href="./css/style.css"> 
<link rel="stylesheet" type="text/css" href="./css/normalize.css"> 
<link rel="stylesheet" type="text/css" href="./css/print.css" media="print" > 
<title><?php echo $Title ?></title>
<base target="principal">
</head>

<body topmargin="0" bgcolor="#f2f2f2">

<form style="margin: 0px 0 0px 0px;text-align: center;border: 1px solid #167F92;height: 46px;width: 98%;padding: 19px 0 0 0px;border-radius: 10px;" class="responsive" name="form1" method="POST" action="lista_consulta.php" target="principal_2">
	<span align="center">
		Consulta
	</span>
	<input type="text" name="consulta" size="23"> 
		<span>
			em
		</span>
	
	  <select size="1" name="filtro">
	  <option value="codigo"><span>-Escolha o Filtro-</span></option>
	  <option value="codigo">Codigo</option>
	  <option value="data_abertura">Data de Abertura</option>
	  <option value="hora_abertura">Hora Abertura</option>
	  <option value="setor">Setor</option>
	  <option value="ip">IP</option>
	  <option value="tipo">Tipo</option>
	  <option value="nome">Nome</option>
	  </select> <b><font face="Arial" size="2"></font></b>
	  <select size="1" name="status">
	  <option value="">-Em Todos-</option>
	  <option value="a">A - Aberto</option>
	  <option value="f">F - Fechado</option>
	  <option value="e">E - Em andamento</option>
	  </select>
	  <input style="background: #167F92;   border: none;    color: white;    font-size: 12px;    padding: 4px;    border-radius: 2px;" 
	  type="submit" value="OK" name="B1">
  
  		<form style="text-align: center;" method="POST" action="listar_chamado.php" target="principal_2">
	   <input style="background: #167F92;   border: none;    color: white;    font-size: 12px;    padding: 4px;    border-radius: 2px;"  type="submit" value="          MOSTRA TODOS          " name="B1"></p>
	</form>

	</form>
	
	
</body>

</html>
