<?php
    date_default_timezone_set("America/Fortaleza");
    $date = date("y/m/d");
    $hora = date("H:i");
    include "config.php";
    include "valida_user.inc";
     include "layout.php";
     $mysqli = new mysqli($Host,  $Usuario, $Senha, $Base);
      $sQuery = "insert into chamados (data_abertura, hora_abertura, setor, ip, descricao, solucao, tipo, nome, email, status, obs, tecnico)
                 values ('" . $date . "',
                         '" . $hora  . "',
                         '" . $_POST["setor"]  . "',
                         '" . $_POST["ip"]  . "',
                         '" . $_POST["descricao"]  . "',
                         '" . $_POST["solucao"]  . "',
                         '" . $_POST["tipo"]  . "',
                         '" . $_POST["nome"]  . "',
                         '" . $_POST["email"]  . "',
                         '" . $_POST["status"]  . "',
                         '" . $_POST["obs"]  . "',
                         '" . $nome_usuario  . "')";

   if ($mysqli->query($sQuery)) {
      echo "<script>window.location='lista_chamados_geral.php'</script>";
   } else {
       echo "Problemas gravando chamado\n";
   }

   exit;
?>
